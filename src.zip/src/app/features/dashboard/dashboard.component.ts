// src/app/features/dashboard/dashboard.component.ts
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Observable, combineLatest, Subject, of } from 'rxjs';
import { map, takeUntil, startWith } from 'rxjs/operators';
import { Option } from '../../masters/ship-master/ship.model';
import { CommandService } from '../../masters/ship-master/ship-services/command.service';
import { ShipService } from '../../masters/ship-master/ship.service';
import { DepartmentService } from '../../masters/ship-master/ship-services/department.service';
import { MessageService } from 'primeng/api';
import { DefectListComponent } from './defect-list/defect-list.component'; // Correct path

interface OcrcEvent {
  ship: string;
  opStart: Date;
  opEnd: Date;
  refStart: Date;
  refEnd: Date;
  refitType: string;
}

interface ChartData {
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    backgroundColor?: string[];
    borderColor?: string[];
    borderWidth?: number;
  }[];
}

interface KpiCardData {
  value: number | string;
  trend?: number;
  trendDirection?: 'up' | 'down';
  progress?: number;
  progressText?: string;
  severity?: { critical: number; major: number; minor: number };
  overdueTasks?: number;
}

interface FleetStatus {
  ship: string;
  readiness: number; // percentage
  defects: number;
  maintenance: string; // e.g., "Due 2 weeks"
}

interface NewDefect {
  ship: number | null;
  department: number | null;
  title: string;
  description: string;
  defectType: string | null;
  system: string | null;
  equipment: string | null;
  priority: string | null;
  attachments: File[]; // For file upload
}

interface MaintenanceLog {
  maintenanceType: string | null;
  frequency: string | null;
  task: string;
  equipment: string | null;
  assignedPersonnel: string | null;
  hours: number | null;
  completionDate: Date | null;
  sparesUsed: string;
  remarks: string;
}

interface EquipmentItem {
  name: string;
  nsn?: string; // National Stock Number
  partNumber?: string;
  department?: string;
  compartment?: string;
  status: string; // Operational, In Maintenance, etc.
}

@Component({
  selector: 'app-dashboard',
  standalone: false,
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, OnDestroy {
  @ViewChild(DefectListComponent) defectListComponent!: DefectListComponent;

  userInitials = 'JD';
  userName = 'John Doe';
  userRank = 'Commander';
  userRole = 'Maintenance Supervisor';
  isApprover: boolean = true;
  totalEquipment: number = 245;
  activeMaintenanceTasks: number = 87;
  activeMaintenanceProgress: number = 62;
  openDefects: number = 34;
  criticalDefects: number = 8;
  majorDefects: number = 15;
  minorDefects: number = 11;
  equipmentFitProgress: number = 100;
  equipmentFitSystemsCount: string = '191/245 systems';
  taskCompletionRate: number = 92;
  overdueTasks: number = 5;
  timelineData: OcrcEvent[] = [];

  commands$: Observable<Option[]>;
  allShips$: Observable<Option[]>;
  departments$: Observable<Option[]>;

  private _allCommands: Option[] = [];
  private _allShips: Option[] = [];
  private _allDepartments: Option[] = [];

  filteredShips: Option[] = [];
  filteredDepartments: Option[] = [];

  selectedCommand:any='';
  selectedShip:any='';
  selectedDept:any='';
  dateRange: Date[] | undefined; // Keep this if other parts of dashboard use it, but it's not passed to DefectListComponent

  kpiMetrics = [
    {
      title: 'Total Equipment',
      value: 245,
      description: 'Total equipment across all units.',
      iconClass: 'pi pi-cog',
      type: 'TOTAL_EQUIPMENT',
      backgroundColor: 'white',
      iconColor: '#022B5A',
      titleColor: '#022B5A',
      valueColor: '#022B5A',
      trendPercentage: '3.2%',
      trendDirection: 'up'
    },
    {
      title: 'Active Tasks',
      value: 87,
      iconClass: 'pi pi-calendar',
      type: 'ACTIVE_MAINTENANCE_TASKS',
      backgroundColor: 'white',
      iconColor: '#6B7C8F',
      titleColor: '#6B7C8F',
      valueColor: '#6B7C8F',
      progressBarValue: 62,
    },
    {
      title: 'Open Defects',
      value: 34,
      iconClass: 'pi pi-exclamation-triangle',
      type: 'OPEN_DEFECTS',
      backgroundColor: 'white',
      iconColor: '#E53935',
      titleColor: '#E53935',
      valueColor: '#E53935',
      severityDetails: { critical: 8, major: 15, minor: 11 }
    },
    {
      title: 'Equipment Fit Progress',
      value: '100%',
      iconClass: 'pi pi-check-square',
      type: 'EQUIPMENT_FIT_PROGRESS',
      backgroundColor: 'white',
      iconColor: '#4CAF50',
      titleColor: '#4CAF50',
      valueColor: '#4CAF50',
      subText: '191/245 systems'
    },
    {
      title: 'Task Completion Rate',
      value: '92%',
      iconClass: 'pi pi-chart-line',
      type: 'TASK_COMPLETION_RATE',
      backgroundColor: 'white',
      iconColor: '#FF6B35',
      titleColor: '#FF6B35',
      valueColor: '#FF6B35',
      subText: '5 overdue tasks'
    },
  ];

  taskDistributionData: ChartData = { labels: [], datasets: [] };
  maintenanceTimelineData: ChartData = { labels: [], datasets: [] };
  defectsData: ChartData = { labels: [], datasets: [] };
  frequentDefectData: ChartData = { labels: [], datasets: [] };

  fleetStatus: FleetStatus[] = [];

  showNewDefectDialog: boolean = false;
  newDefect: NewDefect = {
    ship: null, department: null, title: '', description: '',
    defectType: null, system: null, equipment: null, priority: null, attachments: []
  };

  shipsForDefect: Option[] = [];
  departmentsForDefect: Option[] = [];

  defectTypeOptions: Option[] = [
    { label: 'Mechanical', value: 'Mechanical' },
    { label: 'Electrical', value: 'Electrical' },
    { label: 'Software', value: 'Software' },
    { label: 'Structural', value: 'Structural' },
  ];
  systemOptions: Option[] = [
    { label: 'Propulsion System', value: 'Propulsion' },
    { label: 'Navigation System', value: 'Navigation' },
    { label: 'Weapon System', value: 'Weapon' },
    { label: 'Power Generation', value: 'Power' },
  ];
  equipmentOptions: Option[] = [
    { label: 'Main Engine #1', value: 'Main Engine #1' },
    { label: 'Radar System', value: 'Radar System' },
    { label: 'Sonar Array', value: 'Sonar Array' },
    { label: 'HVAC Unit A', value: 'HVAC Unit A' },
  ];
  priorityOptions: Option[] = [
    { label: 'Critical', value: 'Critical' },
    { label: 'High', value: 'High' },
    { label: 'Medium', value: 'Medium' },
    { label: 'Low', value: 'Low' },
  ];

  showLogMaintenanceDialog: boolean = false;
  maintenanceLog: MaintenanceLog = {
    maintenanceType: null, frequency: null, task: '', equipment: null,
    assignedPersonnel: null, hours: null, completionDate: null, sparesUsed: '', remarks: ''
  };
  maintenanceTypeOptions: Option[] = [
    { label: 'Preventive', value: 'Preventive' },
    { label: 'Corrective', value: 'Corrective' },
    { label: 'Predictive', value: 'Predictive' },
  ];
  maintenanceFrequencyOptions: Option[] = [
    { label: 'Daily', value: 'Daily' },
    { label: 'Weekly', value: 'Weekly' },
    { label: 'Monthly', value: 'Monthly' },
    { label: 'Quarterly', value: 'Quarterly' },
    { label: 'Annually', value: 'Annually' },
  ];
  personnelOptions: Option[] = [
    { label: 'CPO R. Sharma', value: 'R. Sharma' },
    { label: 'LT J. Khan', value: 'J. Khan' },
    { label: 'CDR S. Patel', value: 'S. Patel' },
  ];

  showEquipmentFitDialog: boolean = false;
  selectedEFCommand: number | null = null;
  selectedEFShip: number | null = null;
  equipmentList: EquipmentItem[] = [
    { name: 'Main Engine #1', nsn: '1234-56-789-0123', department: 'Engineering', compartment: 'Engine Room A', status: 'Operational' },
    { name: 'Radar System', partNumber: 'XYZ-987', department: 'Operations', compartment: 'Bridge', status: 'Operational' },
    { name: 'HVAC Unit B', nsn: '9876-54-321-0987', department: 'Logistics', compartment: 'Deck 3', status: 'In Maintenance' },
    { name: 'Sonar Array', partNumber: 'ABC-111', department: 'Weapons', compartment: 'Sonar Bay', status: 'Operational' },
    { name: 'Auxiliary Generator', nsn: '5555-44-333-2222', department: 'Engineering', compartment: 'Engine Room B', status: 'Operational' },
  ];

  showApprovePlanDialog: boolean = false;
  approverComments: string = '';

  private destroy$ = new Subject<void>();

  constructor(
    private commandService: CommandService,
    private shipService: ShipService,
    private departmentService: DepartmentService,
    private messageService: MessageService
  ) {
    this.commands$ = this.commandService.getCommandOptions();
    this.allShips$ = this.shipService.getShipOptions();
    this.departments$ = this.departmentService.getDepartmentOptions();
  }

  ngOnInit(): void {
    this.loadDefaultData();

    combineLatest([
      this.commands$,
      this.allShips$,
      this.departments$,
    ]).pipe(
      takeUntil(this.destroy$)
    ).subscribe(([commands, allShips, departments]) => {
      this._allCommands = commands;
      this._allShips = allShips;
      this._allDepartments = departments;

      this.shipsForDefect = allShips.filter(s => s.value !== null);
      this.departmentsForDefect = departments.filter(d => d.value !== null);

      // Initialize filter dropdowns based on loaded data without triggering applyFilters
      this.applyShipAndDepartmentFilters(this._allShips, this._allCommands, this._allDepartments);

      // IMPORTANT: Trigger applyFilters *once* after all initial data and dropdowns are ready
      // This ensures the initial charts (both mock and API-driven) are populated.
      // This is still needed for initial load.
      this.applyFilters();
    });

    this.commandService.loadAllCommandsData();
    this.shipService.loadAllShipsData();
    this.departmentService.loadAllDepartmentsData();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadDefaultData(): void {
    this.fleetStatus = [
      { ship: 'INS Vikrant', readiness: 95, defects: 2, maintenance: 'None' },
      { ship: 'INS Vikramaditya', readiness: 78, defects: 5, maintenance: 'Scheduled (1 week)' },
      { ship: 'INS Chennai', readiness: 88, defects: 1, maintenance: 'None' },
      { ship: 'INS Shivalik', readiness: 65, defects: 8, maintenance: 'In Progress' },
      { ship: 'INS Kamorta', readiness: 92, defects: 0, maintenance: 'None' },
    ];

    const allShipNames = this.fleetStatus.map(fs => fs.ship);
    this.timelineData = this.getMockTimelineData(allShipNames);
  }

  // New method to apply filters only for the mock charts (not for the defect-list component)
  applyFiltersForMockCharts(): void {
    let selectedShipNames: string[] = [];
    if (this.selectedShip) {
      const foundShip = this._allShips.find(s => s.value === this.selectedShip);
      if (foundShip?.label) {
        selectedShipNames = [foundShip.label];
      }
    } else {
      let shipsToConsider = this._allShips;
      if (this.selectedCommand !== null) {
        // This logic assumes 'Option' for ships might have a 'commandId' or similar
        // If not, you'd need to adjust how ships relate to commands
        shipsToConsider = this._allShips.filter(s => (s as any).commandId === this.selectedCommand);
      }
      selectedShipNames = shipsToConsider.filter(s => s.value !== null).map(s => s.label);
    }
    this.timelineData = this.getMockTimelineData(selectedShipNames);

    this.frequentDefectData = {
      labels: ['Filtered A', 'Filtered B', 'Filtered C'],
      datasets: [{
        label: 'Filtered Frequency',
        backgroundColor: ['#42A5F5', '#66BB6A', '#FFA726'],
        data: [3, 2, 4]
      }]
    };

    this.taskDistributionData = {
      labels: ['Engineering', 'Operations', 'Logistics', 'Medical', 'Weapons'],
      datasets: [{
        label: 'Filtered Tasks',
        backgroundColor: ['#42A5F5', '#66BB6A', '#FFA726', '#EF5350', '#AB47BC'],
        data: [15, 25, 10, 5, 20]
      }]
    };

    this.maintenanceTimelineData = {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
      datasets: [
        {
          label: 'Filtered Planned',
          backgroundColor: ['#42A5F5'],
          data: [45, 40, 55, 50, 30, 35]
        },
        {
          label: 'Filtered Unplanned',
          backgroundColor: ['#EF5350'],
          data: [25, 35, 20, 15, 50, 20]
        }
      ]
    };

    this.defectsData = {
      labels: ['Engine', 'Navigation', 'Electrical'],
      datasets: [{
        label: 'Filtered Defects',
        backgroundColor: ['#FF6384'],
        data: [6, 2, 4]
      }]
    };
  }

  applyFilters(): void {
    console.log('Applying filters:', {
      command: this.selectedCommand,
      ship: this.selectedShip,
      department: this.selectedDept
    });

    // Update mock charts
    this.applyFiltersForMockCharts();

    // Trigger API call for DefectListComponent only
    if (this.defectListComponent) {
      // Pass the current filter values directly to the child component's method
      // The child component's fetchData will now use these updated values
      this.defectListComponent.fetchData();
    }
  }

  onCommandChange(): void {
    // Reset dependent filters
    this.selectedShip = null;
    this.selectedDept = null;

    // Re-filter ships based on the new command
    this.applyShipAndDepartmentFilters(this._allShips, this._allCommands, this._allDepartments);

    // DO NOT call applyFilters() here.
    // The user must click 'Apply' to trigger data fetching.
  }

  onShipChange(): void {
    // Reset dependent filters
    this.selectedDept = null;
    // DO NOT call applyFilters() here.
  }

  onDeptChange(): void {
    // DO NOT call applyFilters() here.
  }

  clearFilters(): void {
    this.selectedCommand = null;
    this.selectedShip = null;
    this.selectedDept = null;
    this.dateRange = undefined; // Clear the date range
    // Reset dropdowns based on the new null selections
    this.applyShipAndDepartmentFilters(this._allShips, this._allCommands, this._allDepartments);
    // After clearing, trigger the applyFilters to update all charts, including the DefectListComponent
    this.applyFilters();
  }

  applyShipAndDepartmentFilters(allShips: Option[], allCommands: Option[], allDepartments: Option[]): void {
    let filtered = allShips.filter(ship =>
      // This is a crucial line. Assuming your 'Option' type for ships has a 'commandId' property.
      // If not, you need to adjust how your ship options are structured or filtered.
      // For example, if ship.value is the command ID itself for filtering, it would be:
      // this.selectedCommand === null || ship.value === this.selectedCommand
      // But typically, a ship option would have its own ID as `value` and a `commandId` for filtering.
      // Given your current error with type 'number | null' not assignable to type 'string | null',
      // and your API expecting string IDs, it's safer to ensure value is treated as a string for comparison.
      this.selectedCommand === null || (ship as any).value === this.selectedCommand
    )
    this.filteredShips = [{ label: 'All Ships', value: null }, ...filtered];

    this.filteredDepartments = [{ label: 'All Departments', value: null }, ...allDepartments];

    this.shipsForDefect = allShips.filter(s => s.value !== null);
    this.departmentsForDefect = allDepartments.filter(d => d.value !== null);
  }

  getStatusClass(readiness: number): string {
    if (readiness >= 90) return 'operational';
    if (readiness >= 75) return 'limited';
    return 'in-maintenance';
  }

  getStatusClassd(status: string): string {
    switch (status) {
      case 'Operational': return 'status-operational';
      case 'In Maintenance': return 'status-in-maintenance';
      default: return '';
    }
  }

  addNewDefect(): void {
    this.newDefect = {
      ship: null, department: null, title: '', description: '',
      defectType: null, system: null, equipment: null, priority: null, attachments: []
    };
    this.showNewDefectDialog = true;
    console.log('Opening Add New Defect Dialog');
  }

  submitNewDefect(): void {
    console.log('Submitting new defect:', this.newDefect);
    if (this.newDefect.ship === null || this.newDefect.department === null || !this.newDefect.title || !this.newDefect.description ||
      !this.newDefect.defectType || !this.newDefect.system || !this.newDefect.equipment || !this.newDefect.priority) {
      this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Please fill in all required fields for the new defect.' });
      return;
    }
    setTimeout(() => {
      this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Defect submitted successfully!' });
      this.showNewDefectDialog = false;
    }, 1000);
  }

  logMaintenance(): void {
    this.maintenanceLog = {
      maintenanceType: null, frequency: null, task: '', equipment: null,
      assignedPersonnel: null, hours: null, completionDate: null, sparesUsed: '', remarks: ''
    };
    this.showLogMaintenanceDialog = true;
    console.log('Opening Log Maintenance Dialog');
  }

  submitMaintenanceLog(): void {
    console.log('Submitting maintenance log:', this.maintenanceLog);
    if (!this.maintenanceLog.maintenanceType || !this.maintenanceLog.frequency || !this.maintenanceLog.task ||
      !this.maintenanceLog.equipment || !this.maintenanceLog.assignedPersonnel || this.maintenanceLog.hours === null ||
      !this.maintenanceLog.completionDate) {
      this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Please fill in all required fields for the maintenance log.' });
      return;
    }
    setTimeout(() => {
      this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Maintenance log submitted successfully!' });
      this.showLogMaintenanceDialog = false;
    }, 1000);
  }

  viewEquipmentFit(): void {
    this.showEquipmentFitDialog = true;
    console.log('Opening View Equipment Fit Dialog');
  }

  approveMaintenancePlan(): void {
    console.log('Approving/Rejecting Maintenance Plan with comments:', this.approverComments);
    setTimeout(() => {
      this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Maintenance plan action recorded!' });
      this.showApprovePlanDialog = false;
    }, 1000);
  }

  onChartSelect(event: any): void {
    console.log('Chart segment selected:', event);
  }

  getMockTimelineData(ships: string[]): OcrcEvent[] {
    const arr: OcrcEvent[] = [];
    const base = new Date();
    base.setFullYear(2025, 6, 7); // Set to today's date

    ships.forEach((s, i) => {
      arr.push({
        ship: s,
        opStart: new Date(base.getFullYear(), base.getMonth(), base.getDate() + (i * 2), 9, 0),
        opEnd: new Date(base.getFullYear(), base.getMonth(), base.getDate() + (i * 2) + 1, 12, 0),
        refStart: new Date(base.getFullYear(), base.getMonth(), base.getDate() + (i * 2) + 2, 13, 0),
        refEnd: new Date(base.getFullYear(), base.getMonth(), base.getDate() + (i * 2) + 3, 17, 0),
        refitType: i % 2 ? 'Short Refit' : 'Long Refit'
      });
    });
    return arr;
  }
}