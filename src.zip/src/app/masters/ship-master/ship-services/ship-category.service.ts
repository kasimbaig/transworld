// src/app/masters/ship-master/ship-services/ship-category.service.ts (Matches user's provided code)
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { ApiService } from '../../../services/api.service';
import { ShipCategory } from '../../../shared/models/ship-category.model'; // Assuming this model exists
import { Option } from '../ship.model';

@Injectable({
  providedIn: 'root',
})
export class ShipCategoryService {
  private categoryEndpoint = 'master/ship-category/';
  private categoriesSubject = new BehaviorSubject<ShipCategory[]>([]);
  private categoryOptionsSubject = new BehaviorSubject<Option[]>([]);
  private loadingSubject = new BehaviorSubject<boolean>(false);

  constructor(private apiService: ApiService) {}

  getCategories(): Observable<ShipCategory[]> {
    return this.categoriesSubject.asObservable();
  }

  getCategoryOptions(): Observable<Option[]> {
    return this.categoryOptionsSubject.asObservable();
  }

  getLoading(): Observable<boolean> {
    return this.loadingSubject.asObservable();
  }

  loadAllCategoriesData(): void {
    this.loadingSubject.next(true);
    this.apiService.get<ShipCategory[]>(this.categoryEndpoint).pipe(
      tap(categories => {
        this.categoriesSubject.next(categories);
        const options = categories.map(category => ({
          label: category.name,
          value: category.id as number
        }));
        this.categoryOptionsSubject.next(options);
      })
    ).subscribe({
      next: () => this.loadingSubject.next(false),
      error: (error) => {
        this.loadingSubject.next(false);
        this.categoryOptionsSubject.next([]);
        console.error('Error loading ship categories:', error);
      }
    });
  }

  addCategory(category: Omit<ShipCategory, 'id' | 'active'>): Observable<ShipCategory> {
    return this.apiService.post<ShipCategory>(this.categoryEndpoint, category).pipe(
      tap(() => this.loadAllCategoriesData())
    );
  }

  updateCategory(id: number, category: ShipCategory): Observable<ShipCategory> {
    return this.apiService.put<ShipCategory>(`${this.categoryEndpoint}${id}/`, category).pipe(
      tap(() => this.loadAllCategoriesData())
    );
  }

  deleteCategory(id: number): Observable<any> {
    return this.apiService.delete(`${this.categoryEndpoint}${id}/`).pipe(
      tap(() => this.loadAllCategoriesData())
    );
  }
}
