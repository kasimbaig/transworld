import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { Dialog } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { Table, TableModule } from 'primeng/table';
import { ApiService } from '../../../services/api.service';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { TieredMenuModule } from 'primeng/tieredmenu';
import { AddFormComponent } from '../../../shared/components/add-form/add-form.component';
import { CommonModule,Location } from '@angular/common';
import { ToastService } from '../../../services/toast.service';
import { PaginatedTableComponent } from '../../../shared/components/paginated-table/paginated-table.component';
import { ToastComponent } from '../../../shared/components/toast/toast.component';
import { ShipCategory } from '../../../shared/models/ship-category.model';
import { ShipCategoryService } from '../ship-services/ship-category.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-ship-category',
  imports: [
    Dialog,
    TableModule,
    AddFormComponent,
    CommonModule,
    ButtonModule,
    InputTextModule,
    FormsModule,
    TieredMenuModule,
    PaginatedTableComponent,
    ToastComponent

  ],
  templateUrl: './ship-category.component.html',
  styleUrl: './ship-category.component.css',
})
export class ShipCategoryComponent implements OnInit { // Implement OnInit
  searchText: string = '';
  isFormOpen: boolean = false;
  title: string = 'Add new Ship Category';
  
  // Use Observable for departments to react to service updates
  departments$!: Observable<ShipCategory[]>; 
  
  deptdisplayModal: boolean = false;
  viewdisplayModal: boolean = false;
  editdisplayModal: boolean = false;
  deletedisplayModal: boolean = false;
  isEditFormOpen: boolean = false;
  editTitle: string = 'Edit Ship Category';

  newDepartment: ShipCategory = {
    code: '',
    name: '',
    active: 1,
    id: 0,
    created_by: null
  };
  selectedDept: ShipCategory | null = null; // Type this as ShipCategory or null

  formConfigForNewDetails = [
    {
      label: 'Name',
      key: 'name',
      type: 'text',
      required: true,
    },
    {
      label: 'Code',
      key: 'code',
      type: 'text',
      required: true,
    },
  ];

  // We will manage filtered data locally for search.
  // The 'departments' property will hold the current data for the table
  departments: ShipCategory[] = [];
  private allCategories: ShipCategory[] = []; // To hold all data for filtering

  toggleForm(open: boolean) {
    this.isFormOpen = open;
  }

  // Inject ShipCategoryService
  constructor(
    private shipCategoryService: ShipCategoryService, // Injected ShipCategoryService
    private toastService: ToastService,
    private location: Location,
    private apiService: ApiService // Keep ApiService if used for generic calls or other non-category entities
  ) {}

  ngOnInit(): void {
    // Load all categories data when the component initializes
    this.shipCategoryService.loadAllCategoriesData();
    // Subscribe to the categories observable from the service
    this.departments$ = this.shipCategoryService.getCategories();
    
    // Subscribe to populate local 'departments' array for filtering and display
    this.departments$.subscribe((data: ShipCategory[]) => {
      this.allCategories = data; // Store original data
      this.departments = [...data]; // Initial data for table
      this.filterDepartments(); // Apply initial filter if searchText is not empty
    });
  }

  goBack(): void {
    this.location.back();
  }

  // Filter function now operates on 'allCategories'
  filterDepartments(): void {
    const search = this.searchText.toLowerCase().trim();

    if (!search) {
      this.departments = [...this.allCategories]; // Reset to original list if search is empty
      return;
    }

    this.departments = this.allCategories.filter(
      (dept: { name: string; code: string; }) => // Adjusted type for clarity
        dept.name.toLowerCase().includes(search) ||
        dept.code.toLowerCase().includes(search)
    );
  }

  openAddDept(): void {
    this.isFormOpen = true; // Use the toggleForm input of AddFormComponent
    this.title = 'Add new Ship Category';
    this.isEditFormOpen = false; // Ensure it's not in edit mode
    this.selectedDept = null; // Clear selected department for new entry
  }

  closeDialog(): void {
    this.deptdisplayModal = false; // This is if you use PrimeNG Dialog directly
    this.viewdisplayModal = false;
    this.deletedisplayModal = false;
    this.editdisplayModal = false;
    this.isFormOpen = false; // Close AddFormComponent
    this.isEditFormOpen = false; // Close AddFormComponent in edit mode
    this.selectedDept = null; // Clear selected department
  }

  handleSubmit(data: any): void {
    // The data coming from AddFormComponent should match ShipCategory structure
    const newCategory: ShipCategory = { ...data, active: 1 }; // Ensure 'active' is set if not provided by form
    
    this.shipCategoryService.addCategory(newCategory).subscribe({
      next: (addedCategory) => {
        this.toastService.showSuccess('Ship Category added successfully');
        // The service's BehaviorSubject will update the departments$ Observable,
        // which will then update the local 'departments' array via subscription.
        this.closeDialog();
      },
      error: (error) => {
        console.error('Error adding ship category:', error);
        this.toastService.showError('Failed to add Ship Category: ' + (error.message || 'Unknown error'));
      },
    });
  }

  viewDeptDetails(dept: ShipCategory): void {
    this.viewdisplayModal = true; // For PrimeNG Dialog
    this.selectedDept = dept;
    // If you're using AddFormComponent for view, you'd do:
    // this.isViewDetailsOpen = true; // Assuming a similar property for ViewDetails
    // this.selectedDept = dept;
  }

  editDetails(details: ShipCategory): void {
    this.selectedDept = { ...details }; // Clone to avoid direct mutation
    this.isEditFormOpen = true; // Open AddFormComponent in edit mode
    this.title = 'Edit Ship Category'; // Change title for edit
    this.isFormOpen = true; // Open the add-form component
  }

  deleteDeptDetails(dept: ShipCategory): void {
    this.deletedisplayModal = true;
    this.selectedDept = dept;
  }

  confirmDeletion(): void {
    if (this.selectedDept && this.selectedDept.id) {
      this.shipCategoryService.deleteCategory(this.selectedDept.id).subscribe({
        next: () => {
          this.toastService.showSuccess('Ship Category deleted successfully');
          // Service's BehaviorSubject will update and refresh the list
          this.closeDialog();
          this.deletedisplayModal = false;
        },
        error: (error) => {
          console.error('Error deleting ship category:', error);
          this.toastService.showError('Failed to delete Ship Category: ' + (error.message || 'Unknown error'));
        },
      });
    } else {
      this.toastService.showError('No ship category selected for deletion.');
    }
  }

  handleEditSubmit(data: any): void {
    if (this.selectedDept && this.selectedDept.id) {
      // Merge changes from form data into the selectedDept
      const updatedCategory: ShipCategory = { ...this.selectedDept, ...data };
      
      this.shipCategoryService.updateCategory(this.selectedDept.id, updatedCategory).subscribe({
        next: (response) => {
          this.toastService.showSuccess('Ship Category updated successfully');
          // Service's BehaviorSubject will update and refresh the list
          this.closeDialog();
        },
        error: (error) => {
          console.error('Error updating ship category:', error);
          this.toastService.showError('Failed to update Ship Category: ' + (error.message || 'Unknown error'));
        },
      });
    } else {
      this.toastService.showError('No ship category selected for update.');
    }
  }

  exportOptions = [
    {
      label: 'Export as PDF',
      icon: 'pi pi-file-pdf',
      command: () => this.exportPDF(),
    },
    {
      label: 'Export as Excel',
      icon: 'pi pi-file-excel',
      command: () => this.exportExcel(),
    },
  ];
  cols = [
    { field: 'name', header: 'Name' },
    { field: 'code', header: 'Code' },
  ];

  @ViewChild('dt') dt!: Table;
  value: number = 0;
  stateOptions: any[] = [
    { label: 'Equipment Specification', value: 'equipment' },
    { label: 'HID Equipment', value: 'hid' },
    { label: 'Generic Specification', value: 'generic' },
  ];
  tabvalue: string = 'equipment';
  @Output() exportCSVEvent = new EventEmitter<void>();
  @Output() exportPDFEvent = new EventEmitter<void>();

  exportPDF(): void {
    console.log('Exporting as PDF...');
    this.exportPDFEvent.emit();
    const doc = new jsPDF();
    autoTable(doc, {
      head: [this.cols.map((col) => col.header)],
      body: this.departments.map((row: { [x: string]: any }) =>
        this.cols.map((col) => row[col.field] || '')
      ),
    });
    doc.save(`${this.tableName || 'ship-categories'}.pdf`); // Changed default table name
  }

  @Input() tableName: string = '';

  exportExcel(): void {
    console.log('Exporting as Excel...');
    this.exportCSVEvent.emit();
    const headers = this.cols.map((col) => col.header);
    const rows = this.departments.map((row: { [x: string]: any }) =>
      this.cols.map((col) => row[col.field] || '')
    );
    const csv = [
      headers.join(','),
      ...rows.map((row: any[]) => row.join(',')),
    ].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${this.tableName || 'ship-categories'}.csv`; // Changed default table name
    link.click();
    window.URL.revokeObjectURL(url);
  }
}