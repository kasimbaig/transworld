import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UnitMasterRoutingModule } from './unit-master-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    UnitMasterRoutingModule
  ]
})
export class UnitMasterModule { }
