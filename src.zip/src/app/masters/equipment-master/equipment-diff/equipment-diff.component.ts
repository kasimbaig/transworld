import {
  Component,
  EventEmitter,
  Input,
  Output,
  ViewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { Table, TableModule } from 'primeng/table';
import { ApiService } from '../../../services/api.service';
import { TieredMenuModule } from 'primeng/tieredmenu';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { AddFormComponent } from '../../../shared/components/add-form/add-form.component';
import { CommonModule, Location } from '@angular/common';
import { PaginatedTableComponent } from '../../../shared/components/paginated-table/paginated-table.component';

@Component({
  selector: 'app-equipment-diff',
  imports: [
    TableModule,
    AddFormComponent,
    CommonModule,
    ButtonModule,
    InputTextModule,
    FormsModule,
    TieredMenuModule,
    PaginatedTableComponent,
  ],
  templateUrl: './equipment-diff.component.html',
  styleUrl: './equipment-diff.component.css',
})
export class EquipmentDiffComponent {
  searchText: string = '';
  title: string = 'Add new Equipment Difference';
  isFormOpen: boolean = false;
  departments: any = [];
  deptdisplayModal: boolean = false;
  viewdisplayModal: boolean = false;
  editdisplayModal: boolean = false;
  deletedisplayModal: boolean = false;
  filteredEquipment: any[] = [];
  filteredSFDHierarchy: any[] = [];
  isEditFormOpen: boolean = false;
  editTitle: string = 'Edit Equipment Difference';

  newDepartment = {
    equipment_1: null,
    sfd_hierarchy: null,
    equipment_2: null,
    common_diff: '',
    active: 1,
  };
  selectedDept: any = {
    equipment_1: null,
    sfd_hierarchy: null,
    equipment_2: null,
    common_diff: '',
    active: 1,
  };

  formConfigForNewDetails = [
    {
      label: 'Equipment 1',
      key: 'equipment_1',
      type: 'select',
      options: this.filteredEquipment,
      required: true,
    },
    {
      label: 'Equipment 2',
      key: 'equipment_2',
      type: 'select',
      options: this.filteredEquipment,
      required: true,
    },
    {
      label: 'Common Difference',
      key: 'common_diff',
      type: 'textarea',
      required: true,
    },

    {
      label: 'SFD Hierarchy',
      key: 'sfd_hierarchy',
      type: 'select',
      options: this.filteredSFDHierarchy,
      required: true,
    },
  ];
  toggleForm(open: boolean) {
    this.isFormOpen = open;
  }
  filteredDepartments: any = [];

  constructor(private apiService: ApiService, private location:Location) {}

  ngOnInit(): void {
    this.getDepartments();
    this.getEquipmentDetails();
    this.getSFDHierarchyDetails();
  }
  goBack(){
    this.location.back();
  }
  getSFDHierarchyDetails(): void {
    this.apiService.get<any[]>('master/sfd-hierarchy/').subscribe({
      next: (data) => {
        console.log(data);
        this.filteredSFDHierarchy = data.map((details: any) => ({
          label: details.name,
          value: details.id,
        }));
        const sfdHierarchyField = this.formConfigForNewDetails.find(
          (field) => field.key === 'sfd_hierarchy'
        );

        if (sfdHierarchyField) {
          sfdHierarchyField.options = this.filteredSFDHierarchy;
        }
      }
    });
  }
  getEquipmentDetails(): void {
    this.apiService.get<any[]>('master/equipment/').subscribe({
      next: (data) => {
        console.log(data);
        this.filteredEquipment = data.map((details: any) => ({
          label: details.name,
          value: details.id,
        }));
        const equipmentField1 = this.formConfigForNewDetails.find(
          (field) => field.key === 'equipment_1'
        );
        const equipmentField2 = this.formConfigForNewDetails.find(
          (field) => field.key === 'equipment_2'
        );

        if (equipmentField1) {
          equipmentField1.options = this.filteredEquipment;
        }
        if (equipmentField2) {
          equipmentField2.options = this.filteredEquipment;
        }
      },
      error: (error) => {
        console.error('Error fetching departments:', error);
      },
    });
  }

  getDepartments(): void {
    this.apiService
      .get<any[]>('sfd/equipment-common-diff/') // Adjust endpoint
      .subscribe({
        next: (data) => {
          this.departments = data;
          this.filteredDepartments = [...this.departments];
        },
        error: (error) => {
          console.error('Error fetching departments:', error);
        },
      });
  }
  // Search function
  filterDepartments() {
    const search = this.searchText.toLowerCase().trim();

    if (!search) {
      this.departments = [...this.filteredDepartments]; // Reset to original list if search is empty
      return;
    }

    this.departments = this.filteredDepartments.filter(
      (dept: { name: string; description: string }) =>
        dept.name.toLowerCase().includes(search) ||
        dept.description.toLowerCase().includes(search)
    );
  }

  closeDialog() {
    this.deptdisplayModal = false;
    this.viewdisplayModal = false;
    this.deletedisplayModal = false;
    this.editdisplayModal = false;
    this.selectedDept = {
      code: '',
      name: '',
      description: '',
    };
  }
  handleSubmit(data: any) {
    this.newDepartment = data;
    let payload = {...this.newDepartment, active: 1};
    console.log('New Department:', this.newDepartment);
    this.apiService
      .post(`sfd/equipment-common-diff/`, payload)
      .subscribe({
        next: (data: any) => {
          console.log(data);
          this.departments.push(data);
          this.filteredDepartments.push(data);
        },
        error: (error) => {
          console.error('Login failed:', error);
          alert('Invalid login credentials');
        },
      });
    this.closeDialog();
  }
  viewDeptDetails(dept: any) {
    this.viewdisplayModal = true;
    console.log(dept);
    this.selectedDept = dept;
  }
  editDetails(dept: any, open: boolean) {
    this.selectedDept = { ...dept };
    this.isEditFormOpen = open;
  }
  deleteDeptDetails(dept: any) {
    this.deletedisplayModal = true;
    this.selectedDept = dept;
  }
  confirmDeletion() {
    this.apiService
      .delete(`sfd/equipment-common-diff/${this.selectedDept.id}/`)
      .subscribe({
        next: (data: any) => {
          console.log(data);
        },
        error: (error) => {
          console.error('Error:', error);
        },
      });
    this.closeDialog();
  }
  handleEditSubmit(data: any) {
    this.selectedDept = { ...this.selectedDept, ...data };
    this.apiService
      .put(
        `sfd/equipment-common-diff/${this.selectedDept.id}/`,
        this.selectedDept
      )
      .subscribe({
        next: (data: any) => {
          console.log(data);
        },
        error: (error) => {
          console.error('Error:', error);
        },
      });
    console.log(this.selectedDept);
    this.closeDialog();
  }
  exportOptions = [
    {
      label: 'Export as PDF',
      icon: 'pi pi-file-pdf',
      command: () => this.exportPDF(),
    },
    {
      label: 'Export as Excel',
      icon: 'pi pi-file-excel',
      command: () => this.exportExcel(),
    },
  ];
  cols = [
    { field: 'equipment', header: 'Equipment Name' },
    { field: 'ship', header: 'Ship' },
    { field: 'no_of_fits', header: 'No. of Fits' },
  ];
  @ViewChild('dt') dt!: Table;
  value: number = 0;
  stateOptions: any[] = [
    { label: 'Equipment Specification', value: 'equipment' },
    { label: 'HID Equipment', value: 'hid' },
    { label: 'Generic Specification', value: 'generic' },
  ];
  tabvalue: string = 'equipment';
  @Output() exportCSVEvent = new EventEmitter<void>();
  @Output() exportPDFEvent = new EventEmitter<void>();
  exportPDF() {
    console.log('Exporting as PDF...');
    // Your PDF export logic here
    this.exportPDFEvent.emit(); // Emit event instead of direct call
    const doc = new jsPDF();
    autoTable(doc, {
      head: [this.cols.map((col) => col.header)],
      body: this.departments.map((row: { [x: string]: any }) =>
        this.cols.map((col) => row[col.field] || '')
      ),
    });
    doc.save(`${this.tableName || 'table'}.pdf`); // ✅ Use backticks
  }
  @Input() tableName: string = '';
  exportExcel() {
    console.log('Exporting as Excel...');
    // Your Excel export logic here
    this.exportCSVEvent.emit(); // Emit event instead of direct call
    const headers = this.cols.map((col) => col.header);
    const rows = this.departments.map((row: { [x: string]: any }) =>
      this.cols.map((col) => row[col.field] || '')
    );
    const csv = [
      headers.join(','),
      ...rows.map((row: any[]) => row.join(',')),
    ].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${this.tableName || 'table'}.csv`; // ✅ Use backticks
    link.click();
    window.URL.revokeObjectURL(url);
  }
}
