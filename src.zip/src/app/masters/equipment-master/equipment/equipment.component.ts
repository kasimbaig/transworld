import {
  Component,
  EventEmitter,
  Input,
  Output,
  ViewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { Table, TableModule } from 'primeng/table';
import { ApiService } from '../../../services/api.service';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { TieredMenuModule } from 'primeng/tieredmenu';
import { AddFormComponent } from '../../../shared/components/add-form/add-form.component';
import { CommonModule, Location } from '@angular/common';
import { forkJoin } from 'rxjs';
import { ToastService } from '../../../services/toast.service';
import { LoadingSpinnerComponent } from '../../../shared/components/loading-spinner/loading-spinner.component';
import { PaginatedTableComponent } from '../../../shared/components/paginated-table/paginated-table.component';
import { ToastComponent } from '../../../shared/components/toast/toast.component';
import { DialogModule } from 'primeng/dialog'; // Import DialogModule for p-dialog
import { PanelModule } from 'primeng/panel'; // Import PanelModule for view details

@Component({
  selector: 'app-equipment',
  standalone: true,
  imports: [
    TableModule,
    AddFormComponent,
    CommonModule,
    ButtonModule,
    InputTextModule,
    FormsModule,
    PaginatedTableComponent,
    TieredMenuModule,
    ToastComponent,
    DialogModule,
    PanelModule
],
  templateUrl: './equipment.component.html',
  styleUrl: './equipment.component.css',
})
export class EquipmentComponent {
  searchText: string = '';
  departments: any = [];
  title: string = 'Add new Equipment';
  isFormOpen: boolean = false;
  viewdisplayModal: boolean = false;
  deletedisplayModal: boolean = false;
  filteredCountry: any[] = [];
  filteredSection: any[] = [];
  filteredGeneric: any[] = [];
  filteredTypes: any[] = [];
  filteredGroups: any[] = [];
  isEditFormOpen: boolean = false;
  editTitle: string = 'Edit Equipment';
  isLoading: boolean = false;

  newDetails: any = {
    code: '',
    name: '',
    country: null,
    group: null,
    image: null,
    model: '',
    manufacture_name: '',
    manufacture_address: '',
    obsolete: false,
    authority: null,
    type: null,
    parent: null,
    active: true,
  };
  selectedDetails: any = {};
  filteredDepartments: any = [];

  formConfigForNewDetails = [
    { label: 'Code', key: 'code', type: 'text', required: true },
    { label: 'Name', key: 'name', type: 'text', required: true },
    { label: 'Country', key: 'country', type: 'select', options: this.filteredCountry, required: true },
    { label: 'Group', key: 'group', type: 'select', options: this.filteredGroups, required: true },
    { label: 'Image', key: 'image', type: 'file', required: false },
    { label: 'Model', key: 'model', type: 'text', required: true },
    { label: 'Manufacture Name', key: 'manufacture_name', type: 'text', required: true },
    { label: 'Manufacture Address', key: 'manufacture_address', type: 'text', required: true },
    { label: 'Obsolete', key: 'obsolete', type: 'checkbox', required: false },
    { label: 'Authority', key: 'authority', type: 'text', required: true },
    { label: 'Type', key: 'type', type: 'select', options: this.filteredTypes, required: true },
    { label: 'Parent', key: 'parent', type: 'select', options: [], required: false },
  ];

  toggleForm(open: boolean) {
    this.isFormOpen = open;
  }

  constructor(private apiService: ApiService, private location: Location, private toastService: ToastService) {}

  ngOnInit(): void {
    this.fetchInitialDropdownData();
  }
  goBack() {
    this.location.back();
  }
  fetchInitialDropdownData(): void {
    this.isLoading = true;
    forkJoin({
      equipments: this.apiService.get<any[]>('master/equipment/'),
      countries: this.apiService.get<any[]>('master/country/'),
      groups: this.apiService.get<any[]>('master/group/'),
      eqType: this.apiService.get<any[]>('master/equipment-type/'),
    }).subscribe({
      next: ({ equipments, countries, groups, eqType }) => {
        this.departments = equipments;
        this.filteredDepartments = [...this.departments];

        this.filteredCountry = countries.map((details: any) => ({
          label: details.name,
          value: details.id,
        }));
        this.setFieldOptions('country', this.filteredCountry);

        this.filteredGroups = groups.map((details: any) => ({
          label: details.name, // Use name for label
          value: details.id,
        }));
        this.setFieldOptions('group', this.filteredGroups);
        this.setFieldOptions('parent', this.filteredGroups); 

        this.filteredTypes = eqType.map((details: any) => ({
          label: details.name, // Use name for label
          value: details.id,
        }));
        this.setFieldOptions('type', this.filteredTypes);

        this.isLoading = false;
      },
      error: (error: any) => {
        this.isLoading = false;
        console.error('Error fetching initial data:', error);
        this.toastService.showError('Error fetching initial data');
      },
    });
  }

  private setFieldOptions(key: string, options: any[]): void {
    const field = this.formConfigForNewDetails.find((f) => f.key === key);
    if (field) {
      field.options = options;
    }
  }

  filterDepartments() {
    const search = this.searchText.toLowerCase().trim();
    if (!search) {
      this.departments = [...this.filteredDepartments];
      return;
    }
    this.departments = this.filteredDepartments.filter(
      (item: any) =>
        item.code?.toLowerCase().includes(search) ||
        item.name?.toLowerCase().includes(search) ||
        item.model?.toLowerCase().includes(search) ||
        item.manufacture_name?.toLowerCase().includes(search)
    );
  }

  closeDialog() {
    this.isFormOpen = false;
    this.isEditFormOpen = false;
    this.viewdisplayModal = false;
    this.deletedisplayModal = false;
    this.selectedDetails = {};
  }

  handleSubmit(data: any) {
    this.isLoading = true;
    const formData = new FormData();
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        if (key === 'image' && data[key] instanceof File) {
          formData.append(key, data[key], data[key].name);
        } else if (key === 'active' || key === 'obsolete') {
          formData.append(key, data[key] ? '1' : '0');
        } else if (data[key] !== null) {
          formData.append(key, data[key]);
        }
      }
    }
    if (!formData.has('active')) {
      formData.append('active', '1');
    }

    this.apiService.post(`master/equipment/`, formData).subscribe({
      next: (res: any) => {
        this.toastService.showSuccess(res.message || 'Equipment added successfully');
        this.getEquipments();
        this.closeDialog();
        this.isLoading = false;
      },
      error: (err) => {
        this.isLoading = false;
        const errorMsg = err?.error?.error || 'Something went wrong';
        this.toastService.showError(errorMsg);
      },
    });
  }

  getEquipments(): void {
    this.isLoading = true;
    this.apiService.get<any[]>('master/equipment/').subscribe({
      next: (data) => {
        this.departments = data;
        this.filteredDepartments = [...this.departments];
        this.isLoading = false;
      },
      error: (error) => {
        this.isLoading = false;
        this.toastService.showError('Error fetching equipment data');
      },
    });
  }

  viewDetails(details: any) {
    this.selectedDetails = { ...details };
    this.viewdisplayModal = true;
  }

  editDetails(details: any, open: boolean) {
    this.isEditFormOpen = open;
    // Map nested objects to their ID values for the form to pre-populate correctly
    this.selectedDetails = {
      ...details,
      country: details.country?.id,
      group: details.group?.id,
      type: details.type?.id,
      parent: details.parent?.id,
    };
  }

  deleteDetails(details: any) {
    this.deletedisplayModal = true;
    this.selectedDetails = details;
  }

  confirmDeletion() {
    this.isLoading = true;
    this.apiService.delete(`master/equipment/${this.selectedDetails.id}/`).subscribe({
      next: (res: any) => {
        this.toastService.showSuccess('Equipment deleted successfully');
        this.departments = this.departments.filter(
          (item: { id: any }) => item.id !== this.selectedDetails.id
        );
        this.filteredDepartments = [...this.departments];
        this.deletedisplayModal = false;
        this.isLoading = false;
      },
      error: (error) => {
        this.isLoading = false;
        console.error('Error:', error);
        this.toastService.showError('Error deleting equipment');
      },
    });
  }

  handleEditSubmit(data: any) {
    this.isLoading = true;
    const formData = new FormData();
    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        if (key === 'image' && data[key] instanceof File) {
          formData.append(key, data[key], data[key].name);
        } else if (key === 'active' || key === 'obsolete') {
          formData.append(key, data[key] ? '1' : '0');
        } else if (data[key] !== null) {
          formData.append(key, data[key]);
        }
      }
    }
    
    this.apiService.put(`master/equipment/${this.selectedDetails.id}/`, formData).subscribe({
      next: (res: any) => {
        this.toastService.showSuccess(res.message || 'Equipment updated successfully');
        this.getEquipments();
        this.closeDialog();
        this.isLoading = false;
      },
      error: (error) => {
        this.isLoading = false;
        console.error('Error:', error);
        this.toastService.showError('Error updating equipment');
      },
    });
  }

  exportOptions = [
    { label: 'Export as PDF', icon: 'pi pi-file-pdf', command: () => this.exportPDF() },
    { label: 'Export as Excel', icon: 'pi pi-file-excel', command: () => this.exportExcel() },
  ];
  cols = [
    { field: 'code', header: 'Code' },
    { field: 'name', header: 'Name' },
    { field: 'model', header: 'Model' },
    { field: 'manufacture_name', header: 'Manufacture Name' },
    { field: 'country.name', header: 'Country' },
    { field: 'group.name', header: 'Group' },
    { field: 'type.name', header: 'Type' },
    { field: 'active', header: 'Active' }
  ];
  @ViewChild('dt') dt!: Table;
  value: number = 0;
  stateOptions: any[] = [
    { label: 'Equipment Specification', value: 'equipment' },
    { label: 'HID Equipment', value: 'hid' },
    { label: 'Generic Specification', value: 'generic' },
  ];
  tabvalue: string = 'equipment';
  @Output() exportCSVEvent = new EventEmitter<void>();
  @Output() exportPDFEvent = new EventEmitter<void>();
  exportPDF() {
    console.log('Exporting as PDF...');
    this.exportPDFEvent.emit();
    const doc = new jsPDF();
    autoTable(doc, {
      head: [this.cols.map((col) => col.header)],
      body: this.departments.map((row: { [x: string]: any }) =>
        this.cols.map((col) => row[col.field] || '')
      ),
    });
    doc.save(`${this.tableName || 'table'}.pdf`);
  }
  @Input() tableName: string = '';
  exportExcel() {
    console.log('Exporting as Excel...');
    this.exportCSVEvent.emit();
    const headers = this.cols.map((col) => col.header);
    const rows = this.departments.map((row: { [x: string]: any }) =>
      this.cols.map((col) => row[col.field] || '')
    );
    const csv = [
      headers.join(','),
      ...rows.map((row: any[]) => row.join(',')),
    ].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${this.tableName || 'table'}.csv`;
    link.click();
    window.URL.revokeObjectURL(url);
  }
}