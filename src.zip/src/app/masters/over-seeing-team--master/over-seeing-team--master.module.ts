import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OverSeeingTeamMasterRoutingModule } from './over-seeing-team--master-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    OverSeeingTeamMasterRoutingModule
  ]
})
export class OverSeeingTeamMasterModule { }
