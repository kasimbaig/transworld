import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MaintopHeaderComponent } from './maintop-header/maintop-header.component';
import { MaintopDetailsComponent } from './maintop-details/maintop-details.component';
import { MaintopJicComponent } from './maintop-jic/maintop-jic.component';
import { JicSpareComponent } from './jic-spare/jic-spare.component';
import { JicToolComponent } from './jic-tool/jic-tool.component';
import { AddressComponent } from './address/address.component';
import { JicAttachmentComponent } from './jic-attachment/jic-attachment.component';
import { LibraryDistDetailComponent } from './library-dist-detail/library-dist-detail.component';
import { LibraryDistComponent } from './library-dist/library-dist.component';
import { TransactionComponent } from './transaction/transaction.component';
import { DistributionAddressComponent } from './distribution-address/distribution-address.component';
import { DashChart1Component } from './dash-chart1/dash-chart1.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MaintopDashboardComponent } from './maintop-dashboard/maintop-dashboard.component';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'maintopheader', component: MaintopHeaderComponent },
  { path: 'maintopdetails', component: MaintopDetailsComponent },
  { path: 'maintopJic', component: MaintopJicComponent },
  { path: 'jicSpare', component: JicSpareComponent },
  { path: 'jicTool', component: JicToolComponent },
  { path: 'addresse', component: AddressComponent },
  { path: 'jicAttachment', component: JicAttachmentComponent },
  { path: 'libraryDistDetail', component: LibraryDistDetailComponent },
  { path: 'libraryDist', component: LibraryDistComponent },
  { path: 'maintopTransaction', component: TransactionComponent },
  { path: 'distributionAddress', component: DistributionAddressComponent },
  // { path: 'dashmaintop', component: DashboardComponent },
    { path: 'dashmaintop', component: MaintopDashboardComponent },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MaintopRoutingModule {}
