import { Component, OnInit, HostListener } from '@angular/core'; // Import HostListener
import { Router, ActivatedRoute, NavigationEnd, RouterOutlet } from '@angular/router';
import { filter } from 'rxjs/operators';
import { CommonModule } from '@angular/common';

interface MasterMenuItem {
  label: string;
  icon: string;
  path: string;
}

@Component({
  selector: 'app-sarar-main-component',
  standalone: true,
  imports: [CommonModule, RouterOutlet],
  templateUrl: './sarar-main-component.component.html',
  styleUrls: ['./sarar-main-component.component.css'],
})
export class SararMainComponentComponent implements OnInit {
  activeSubPath: string = 'sarar-dashboard';
  showMasterDropdown: boolean = false;
  showTransactionsDropdown: boolean = false; // New property for Transactions dropdown

  masterMenuItems: MasterMenuItem[] = [
    {
      icon: 'fa-solid fa-ship',
      label: 'Ship-State',
      path: 'sarar-master/sarar/master-ship-state',
    },{
      icon: 'fa-solid fa-map-marker-alt',
      label: 'Ship Location',
      path: 'sarar-master/sarar/master-ship-location',
    },{
      icon: 'fa-solid fa-microchip',
      label: 'Ship Activity Type',
      path: 'sarar-master/sarar/master-ship-activity-type',
    }, {
      icon: 'fa-solid fa-toolbox',
      label: 'Ship Activity Detail',
      path: 'sarar-master/sarar/master-ship-activity-detail',
    },
    {
      icon: 'fa-solid fa-industry',
      label: 'Lubricant',
      path: 'sarar-master/sarar/master-lubricant',
    },
   
    {
      icon: 'fa-solid fa-chart-line',
      label: 'Equipment',
      path: 'sarar-master/sarar/master-equipment',
    },{
      icon: 'fa-solid fa-ship',
      label: 'Linked Equipment',
      path: 'sarar-master/sarar/master-linked-equipment',
    },
    {
      icon: 'fa-solid fa-sitemap',
      label: 'FPT CST Form',
      path: 'sarar-master/sarar/master-fpt-cst-form',
    },
    
  ];

  transactionMenuItems: MasterMenuItem[] = [
    {
      icon: 'fa-solid fa-paperclip',
      label: 'Adjustment',
      path: 'sarar-transaction/sarar/transaction-adjustment',
    },
    {
      icon: 'fa-solid fa-list',
      label: 'Monthly',
      path: 'sarar-transaction/sarar/transaction-monthly',
    },
    {
      icon: 'fa-solid fa-ship',
      label: 'Status',
      path: 'sarar-transaction/sarar/transaction-status',
    },
    
  ];


  constructor(private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.updateActiveSubPath(this.router.url);

    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      this.updateActiveSubPath(event.urlAfterRedirects);
    });
  }

  private updateActiveSubPath(url: string): void {
    const urlSegments = url.split('/');
    const lastSegment = urlSegments.pop() || urlSegments.pop();

    if (!lastSegment) {
      this.activeSubPath = 'sarar-dashboard';
      return;
    }

    // Check if the current URL is for any of the Master sub-paths
    if (this.masterMenuItems.some(item => url.includes(item.path))) {
      this.activeSubPath = 'sfd-masters';
    }
    // Check if the current URL is for any of the Transactions sub-paths
    else if (this.transactionMenuItems.some(item => url.includes(item.path))) {
      this.activeSubPath = 'sfd-transactions'; // Set 'sfd-transactions' as active
    }
    // Check for other direct paths
    else if (['sfd-dashboard', 'sfd-reports'].includes(lastSegment)) {
      this.activeSubPath = lastSegment;
    }
    // Fallback to dashboard if URL doesn't match
    else {
      this.activeSubPath = 'sarar-dashboard';
    }
  }

  toggleMasterDropdown(): void {
    this.showMasterDropdown = !this.showMasterDropdown;
    this.showTransactionsDropdown = false; // Close other dropdown
  }

  toggleTransactionsDropdown(): void {
    this.showTransactionsDropdown = !this.showTransactionsDropdown;
    this.showMasterDropdown = false; // Close other dropdown
  }

  navigateToSFD(subPath: string): void {
    if (subPath === 'sfd-masters') {
      this.toggleMasterDropdown();
    } else if (subPath === 'sfd-transactions') {
      this.toggleTransactionsDropdown();
    }
    else {
      this.showMasterDropdown = false;
      this.showTransactionsDropdown = false;
      this.activeSubPath = subPath;
      this.router.navigate([subPath], { relativeTo: this.activatedRoute });
    }
  }

  navigateToMasterSubItem(masterPath: string): void {
    this.showMasterDropdown = false;
    this.activeSubPath = 'sfd-masters';
    this.router.navigate([masterPath], { relativeTo: this.activatedRoute });
  }

  navigateToTransactionSubItem(transactionPath: string): void {
    this.showTransactionsDropdown = false; // Close dropdown after selection
    this.activeSubPath = 'sfd-transactions'; // Keep 'Transactions' active
    this.router.navigate([transactionPath], { relativeTo: this.activatedRoute });
  }

  @HostListener('document:click', ['$event'])
  onClickOutside(event: Event) {
    const target = event.target as HTMLElement;
    if (!target.closest('.masters-dropdown-container') && !target.closest('.transactions-dropdown-container')) {
      this.showMasterDropdown = false;
      this.showTransactionsDropdown = false;
    }
  }
}