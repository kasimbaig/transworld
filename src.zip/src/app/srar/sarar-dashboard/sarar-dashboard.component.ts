// cspell:ignore sarar
import { Component } from '@angular/core';

@Component({
  selector: 'app-sarar-dashboard',
  standalone: false,
  templateUrl: './sarar-dashboard.component.html',
  styleUrls: ['./sarar-dashboard.component.css']
})
export class SararDashboardComponent {

}
