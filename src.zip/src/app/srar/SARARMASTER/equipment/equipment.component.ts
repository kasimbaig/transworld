import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { ApiService } from '../../../services/api.service';

@Component({
  selector: 'app-equipment',
standalone:false,
  templateUrl: './equipment.component.html',
  styleUrl: './equipment.component.css'
})
export class EquipmentComponent 
implements OnInit {
  displayDialog: boolean = false;
  isMaximized: boolean = false;
  sararMasterForm: FormGroup = new FormGroup({
    ship_name: new FormControl(''),
    equip_code: new FormControl(''),
    equipment_name: new FormControl(''),
    equipment_nomenclature: new FormControl(''),
    equipment_sr_no: new FormControl(''),
    equipment_type: new FormControl(''),
    location_on_board: new FormControl(''),
    status: new FormControl(''),
  });
 // Table Columns Configuration
 tableColumns = [
  { field: 'ship_name', header: 'Ship Name', type: 'text', sortable: true, filterable: true },
  { field: 'equip_code', header: 'Equip Code', type: 'text', sortable: true, filterable: true },
  { field: 'equipment_name', header: 'Equipment Name', type: 'text', sortable: true, filterable: true },
  { field: 'equipment_nomenclature', header: 'Equipment Nomenclature', type: 'text', sortable: true, filterable: true },
  { field: 'equipment_sr_no', header: 'Equipment SR No', type: 'text', sortable: true, filterable: true },
  { field: 'equipment_type', header: 'Equipment Type', type: 'text', sortable: true, filterable: true },
  { field: 'location_on_board', header: 'Location On Board', type: 'text', sortable: true, filterable: true },
  { field: 'active', header: 'Active', type: 'status', sortable: true, filterable: true },
];

  


  // Table Data
  tableData: any[]   = [
    {
      "ship_name": "INS BARATANG",
      "equip_code": "45201",
      "equipment_name": "DIESEL ENGINE FOR HP AIR COMPRESSOR (1533)",
      "equipment_nomenclature": "ENGINE FOR HP AIR COMPRESSOR",
      "equipment_sr_no": "A4J62191",
      "equipment_type": "Air Compressor",
      "location_on_board": "AFT ENGINE ROOM",
      "active": 1,
      "link_equipment": ""
    },
    {
      "ship_name": "INS BARATANG",
      "equip_code": "45202",
      "equipment_name": "MAIN COOLING WATER PUMP (1534)",
      "equipment_nomenclature": "COOLING WATER PUMP",
      "equipment_sr_no": "B5K73102",
      "equipment_type": "Pump",
      "location_on_board": "AFT ENGINE ROOM",
      "active": 1,
      "link_equipment": ""
    },
    {
      "ship_name": "INS BARATANG",
      "equip_code": "45203",
      "equipment_name": "HYDRAULIC POWER PACK (1535)",
      "equipment_nomenclature": "HYDRAULIC SYSTEM",
      "equipment_sr_no": "C6L84113",
      "equipment_type": "Hydraulic",
      "location_on_board": "FWD ENGINE ROOM",
      "active": 1,
      "link_equipment": ""
    },
    {
      "ship_name": "INS BARATANG",
      "equip_code": "45204",
      "equipment_name": "ELECTRIC GENERATOR SET (1536)",
      "equipment_nomenclature": "GENERATOR",
      "equipment_sr_no": "D7M95124",
      "equipment_type": "Electrical",
      "location_on_board": "GENERATOR ROOM",
      "active": 1,
      "link_equipment": ""
    },
    {
      "ship_name": "INS BARATANG",
      "equip_code": "45205",
      "equipment_name": "FRESH WATER DISTILLATION UNIT (1537)",
      "equipment_nomenclature": "WATER MAKER",
      "equipment_sr_no": "E8N06135",
      "equipment_type": "Utility",
      "location_on_board": "PUMP ROOM",
      "active": 2,
      "link_equipment": ""
    }
  ];
  constructor(private apiService: ApiService, private toast: MessageService) {}
  ngOnInit(): void {
    this.currentPageApi(0 ,0)
    console.log('SFD Component initialized with', this.tableData.length, 'records');
    this.apiCall();
  }
  currentPageApi(page: number, pageSize: number){
    this.apiService.get(`sfd/sfd-details/`).subscribe((res: any) => {
      // this.tableData = res;
    });
  }
apiCall(){
  this.apiService.get('master/ship').subscribe((res: any) => {
    this.shipOptions = res;
  });
}

  crudName='Add'
  openDialog(): void {
    this.displayDialog = true;
  }

  closeDialog(): void {
    this.displayDialog = false;
    this.sararMasterForm.reset();
    this.sararMasterForm.enable();
    this.crudName='Add'
  }


  // Event Handlers
  onView(data: any): void {
    this.crudName='View'
    this.sararMasterForm.patchValue(data);
    this.sararMasterForm.get('status')?.setValue(data.status == 1 ? true : false);
    this.sararMasterForm.disable();
    this.openDialog();
    // Implement view logic
  }
  isEdit: boolean = false;
  onEdit(data: any): void {
    this.isEdit = true;
    this.crudName='Edit'
    this.sararMasterForm.get('status')?.setValue(data.status === 1 ? true : false);
    this.sararMasterForm.patchValue(data);

    this.openDialog();
    // Implement edit logic
  }

  onDelete(data: any): void {
    console.log('Delete SFD:', data);
    // Implement delete logic
  }

  save(){
    console.log(this.sararMasterForm.value);
  }
  
  shipOptions: any[] = [];
  selectedShip: any;
  onShipChange(): void {
    console.log('Selected Ship:', this.selectedShip);
  }

 
}

