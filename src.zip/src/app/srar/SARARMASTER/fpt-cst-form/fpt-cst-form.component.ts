import { Component } from '@angular/core';

@Component({
  selector: 'app-fpt-cst-form',
    standalone:false,
  templateUrl: './fpt-cst-form.component.html',
  styleUrl: './fpt-cst-form.component.css'
})
export class FptCstFormComponent {

}
