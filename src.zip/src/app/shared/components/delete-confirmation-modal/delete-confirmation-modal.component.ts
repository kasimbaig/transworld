import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Button } from "primeng/button";
import { Dialog } from "primeng/dialog";

@Component({
  selector: 'app-delete-confirmation-modal',
  imports: [Button, Dialog],
  templateUrl: './delete-confirmation-modal.component.html',
  styleUrl: './delete-confirmation-modal.component.css'
})
export class DeleteConfirmationModalComponent {
  @Input() visible: boolean = false;
  @Input() message: string = 'Are you sure you want to delete this item?';
  @Output() onConfirm = new EventEmitter<void>();
  @Output() onCancel = new EventEmitter<void>();
}
