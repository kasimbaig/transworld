import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { dartRoutingModule } from './dart-routing.module';
import { FormsModule } from '@angular/forms';
import { NgApexchartsModule } from 'ng-apexcharts';




@NgModule({
  declarations: [],
  imports: [
    FormsModule,
    CommonModule,
    dartRoutingModule,
    NgApexchartsModule
  ]
})
export class dartModule { }
