import { Component } from '@angular/core';

@Component({
  selector: 'app-dart-report',
  standalone: true,

  imports: [],
  templateUrl: './dart-report.component.html',
  styleUrl: './dart-report.component.css'
})
export class DartReportComponent {

}
