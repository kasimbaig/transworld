import { Component, Input } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

interface MenuItem {
  label: string;
  path?: string; // Made optional to allow for parent-only items
  expanded?: boolean;
  children?: MenuItem[];
  icon?: string;
  hasChildren?: boolean;
}

@Component({
  selector: 'app-sidebar',
  standalone: false,
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
})
export class SidebarComponent {
  @Input() isCollapsed: boolean = false;

  expanded: boolean = true;
  activeItem: string = '/dashboard';
  openSubMenus: { [key: string]: boolean } = {};

  themeMode: 'light' | 'dark' = 'light';

  constructor(private router: Router) {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.activeItem = event.urlAfterRedirects;
        this.updateOpenSubMenus(this.activeItem);
      }
    });
  }

  menuItems: MenuItem[] = [
    {
      icon: '📊',
      label: 'Dashboard',
      path: '/dashboard',
      hasChildren: false,
    },

    {
      icon: 'pi pi-database',
      label: 'Masters',
      path: 'masters',
      hasChildren: true,
      children: [
        { icon: ' 🚢 ', label: 'Ship Details', path: '/masters/ship-group' },
        {
          icon: ' 🛠️ ',
          label: 'Equipment Details',
          path: '/masters/equipment-group',
        },
        { icon: ' 👥 ', label: 'Unit Details', path: '/masters/unit-group' },
        {
          icon: ' 👀 ',
          label: 'Overseeing Team',
          path: '/masters/overseeing-team',
        },
        { icon: ' 💨 ', label: 'Propulsion', path: '/masters/propulsion' },
        { icon: ' 🎓 ', label: 'Country', path: '/masters/country' },
        { icon: '', label: 'Establishment', path: '/masters/establishment' },
        { icon: '', label: 'Manufacturer', path: '/masters/manufacturer' }
      ],
    },
    {
      icon: '💰',
      label: 'SFD',
      path: '/sfd',
      hasChildren: false,
    },

    {
      icon: '📅',
      label: 'Maintop',
      path: '/maintop',
      hasChildren: true,
      children: [
        {
          icon: '📊',
          label: 'Dashboard',
          path: '/maintop/dashmaintop',
        },
        {
          icon: '📚',
          label: 'Master',
          path: '/maintop/master',
          hasChildren: true,
          children: [
            {
              icon: '🔖',
              label: 'Header',
              path: '/maintop/maintopheader',
            },
            {
              icon: '📝',
              label: 'Maintop Details',
              path: '/maintop/maintopdetails',
            },
            {
              icon: '🔧',
              label: 'JIC',
              path: '/maintop/maintopJic',
            },
            {
              icon: '🛠️',
              label: 'JIC Tool',
              path: '/maintop/jicTool',
            },
            {
              icon: '📦',
              label: 'JIC Spare',
              path: '/maintop/jicSpare',
            },
            {
              icon: '📦',
              label: 'JIC Attchment',
              path: '/maintop/jicAttachment',
            },
            {
              icon: '⚙️',
              label: 'Addressee',
              path: '/maintop/addresse',
            },
            {
              icon: '⚙️',
              label: 'Dist Address',
              path: '/maintop/distributionAddress',
            },
            {
              icon: '⚙️',
              label: 'Library Dist',
              path: '/maintop/libraryDist',
            },
            {
              icon: '⚙️',
              label: 'Library Dist Detail',
              path: '/maintop/libraryDistDetail',
            },
            {
              icon: '⚙️',
              label: 'Transactions',
              path: '/maintop/maintopTransaction',
            },
          ],
        },
        {
          icon: '📝',
          label: 'Reports',
          path: '/maintop/reports',
        },
      ],
    },
    {
      icon: '⚓',
      label: 'DART',
      path: '/dart',
      hasChildren: true,
      children: [
        {
          icon: '🔖',
          label: 'Dart Dashboard',
          path: '/dart/dart',
        },
        {
          icon: '🔖',
          label: 'Dart Masters',
          path: '/dart/dart-masters',
          hasChildren: true,
          children: [
            {
              icon: '🔖',
              label: 'Delay',
              path: '/dart/dart-delay',
            },
            {
              icon: '🔖',
              label: 'Repair Agency',
              path: '/dart/dart-repairagency',
            },
            {
              icon: '🔖',
              label: 'Refit',
              path: '/dart/dart-refit',
            },
            {
              icon: '🔖',
              label: 'Severity',
              path: '/dart/dart-severity',
            },
            {
              icon: '🔖',
              label: 'Agency',
              path: '/dart/dart-agency',
            },
          ],

        },
        {
          icon: '🔖',
          label: 'Dart Transactions',
          path: '/dart/dart-transaction',
          hasChildren: true,
          children: [{
            icon: '🔖',
            label: 'Defects',
            path: '/dart/dart-defectstroke',
          },
          {
            icon: '🔖',
            label: 'Routine',
            path: '/dart/dart-routine',
          },
          ]
        },
        {
          icon: '🔖',
          label: 'Dart Reports',
          path: '/dart/dart-report',
        },
      ],
    },
        {
      icon: '🚢',
      label: 'SRAR',
      path: '/srar',
      hasChildren: false,
    }
  ];

  // This function will find the parent menu item and open its submenu
  private updateOpenSubMenus(currentPath: string): void {
    this.openSubMenus = {};
    this.menuItems.forEach(item => {
      if (item.children) {
        const found = this.findPathInMenu(item.children, currentPath);
        if (found) {
          // Open the top-level parent and any nested parents
          const parentPaths = this.getParentPaths(item, currentPath);
          parentPaths.forEach(p => {
            this.openSubMenus[p] = true;
          });
        }
      }
    });
  }
  
  private findPathInMenu(menu: MenuItem[], path: string): boolean {
    for (const item of menu) {
      if (item.path === path) {
        return true;
      }
      if (item.children && this.findPathInMenu(item.children, path)) {
        return true;
      }
    }
    return false;
  }

  private getParentPaths(root: MenuItem, childPath: string, paths: string[] = []): string[] {
    if (!root.children) return [];
    for (const child of root.children) {
      if (child.path === childPath) {
        if (root.path) {
          paths.push(root.path);
        }
        return paths;
      }
      if (child.children) {
        const result = this.getParentPaths(child, childPath, paths);
        if (result.length > 0) {
          if (child.path) {
            paths.unshift(child.path);
          }
          return paths;
        }
      }
    }
    return [];
  }


  toggleSidebar() {
    this.expanded = !this.expanded;
    if (!this.expanded) {
      this.openSubMenus = {};
    }
  }

  toggleSubMenu(item: any): void {
    if (item.path) {
      this.openSubMenus[item.path] = !this.openSubMenus[item.path];
    }
  }

  toggleTheme() {
    this.themeMode = this.themeMode === 'light' ? 'dark' : 'light';
    document.body.classList.remove('light', 'dark');
    document.body.classList.add(this.themeMode);
  }

  setActiveItem(item: string) {
    this.activeItem = item;
  }
  
  navigateTo(path: string) {
    this.setActiveItem(path);
    this.activeItem = path;
    this.router.navigate([path]);
  }

  logOut() {
    localStorage.clear();
    window.location.href = '/login';
  }
}