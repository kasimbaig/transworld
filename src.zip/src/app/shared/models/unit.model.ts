export interface Unit {
  id?: number;
  name: string;
  code: string;
  description: string;
  active: number;
}