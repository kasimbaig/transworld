import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GenericSpecificationComponent } from './generic-specification/generic-specification.component';
import { EquipmentSpecificationComponent } from './equipment-specification/equipment-specification.component';
import { EquipmentShipDetailsComponent } from './equipment-ship-details/equipment-ship-details.component';
import { EquipmentSupplierComponent } from './equipment-supplier/equipment-supplier.component';
import { HideEquipmentDetailsComponent } from './hide-equipment-details/hide-equipment-details.component';
import { SfdHierarchyComponent } from './sfd-hierarchy/sfd-hierarchy.component';

const routes: Routes = [
  { path: 'generic-specification', component: GenericSpecificationComponent },
  { path: 'sfd-hierarchy', component: SfdHierarchyComponent },
  { path: 'equipment-ship-details', component: EquipmentShipDetailsComponent },
  { path: 'equipment-supplier', component: EquipmentSupplierComponent },
  { path: 'hide-equipment-details', component: HideEquipmentDetailsComponent },
  { path: 'equipment-specification', component: EquipmentSpecificationComponent, },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SfdMasterRoutingModule { }
