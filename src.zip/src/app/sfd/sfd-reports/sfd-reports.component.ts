import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CardModule } from 'primeng/card';
import { DropdownModule } from 'primeng/dropdown';
import { ButtonModule } from 'primeng/button';
import { Table, TableModule } from 'primeng/table';
import { ApiService } from '../../services/api.service';
import { ChartModule } from 'primeng/chart';
import { SplitButtonModule } from 'primeng/splitbutton';
import { TabsModule } from 'primeng/tabs';
import { TieredMenuModule } from 'primeng/tieredmenu';
import { SelectButton } from 'primeng/selectbutton';
import { forkJoin } from 'rxjs';
import { Card } from '../../interfaces/interfaces';
import { ExportService } from '../../services/export.service';
import { PaginatedTableComponent } from '../../shared/components/paginated-table/paginated-table.component';

@Component({
  selector: 'app-sfd-reports',
  imports: [
    CardModule,
    DropdownModule,
    FormsModule,
    CommonModule,
    ButtonModule,
    TableModule,
    ChartModule,
    SplitButtonModule,
    TabsModule,
    PaginatedTableComponent,
    TieredMenuModule,
    SelectButton,
  ],
  templateUrl: './sfd-reports.component.html',
  styleUrl: './sfd-reports.component.css',
})
export class SfdReportsComponent implements OnInit {
  @Output() exportCSVEvent = new EventEmitter<void>();
  @Output() exportPDFEvent = new EventEmitter<void>();
  @Input() tableName: string = '';
  originalReports: any[] = [];
  constructor(
    private apiService: ApiService,
    private exportService: ExportService
  ) {}

  cards: Card[] = [
    {
      label: 'Command',
      selectedOption: null,
      options: [],
    },
    {
      label: 'Ship',
      selectedOption: null,
      options: [],
    },
    {
      label: 'Section',
      selectedOption: null,
      options: [],
    },
    {
      label: 'Group',
      selectedOption: null,
      options: [],
    },
    {
      label: 'Equipment',
      selectedOption: null,
      options: [],
    },
  ];
  searchReports: string = '';

  // Define table columns
  cols = [
    { field: 'equipment.name', header: 'Equipment' },
    { field: 'ship.name', header: 'Ship' },
    { field: 'group.name', header: 'Group' },
    { field: 'no_of_fits', header: 'Number of fits' },
    { field: 'ref_no', header: 'Referrence Number' },
  ];
  totalRecords: number = 0;
  searchText: string = '';
  @ViewChild('dt') dt!: Table;
  value: number = 0;
  selectedValue: boolean = false;
  shipEquipments: any = [];
  filteredReports: any[] = [];
  initialValue: any = [];
  chartData: any;
  chartOptions: any;
  tab1: any = [];
  equipmentSpecifications: any[] = [];
  hidEquipmentDetails: any[] = [];
  selecedShipId: any;
  hidSpecs: { [key: string]: any } = {};
  eqSpecs: { [key: string]: any } = {};
  // Track which row's menu is open
  activeMenuIndex: number | null = null;
  filterByField(fieldKey: string, id: any): void {
    if (id) {
      this.shipEquipments = this.filteredReports.filter(
        (item) => item[fieldKey]?.id === id
      );
    } else {
      this.shipEquipments = [];
    }
  }
  // Toggle menu visibility
  toggleMenu(index: number) {
    this.activeMenuIndex = this.activeMenuIndex === index ? null : index;
  }
  ngOnInit(): void {
    this.loadInitialData();

    this.apiService
      .get<any[]>(`sfd/equipment-specifications/?equipment=${2}`)
      .subscribe({
        next: (data) => {
          console.log('Equipment Specifications:', data);
          this.equipmentSpecifications = data;
        },
        error: (error) => {
          console.error('Error fetching equipment specifications:', error);
        },
      });
  }

  loadInitialData() {
    forkJoin({
      shipequipments: this.apiService.get<any[]>('sfd/equipment-ship-details/'),
      commands: this.apiService.get<any[]>('/master/command/'),
    }).subscribe({
      next: (response: any) => {
        console.log('API responses:', response);

        this.originalReports = [...response.shipequipments];
        this.filteredReports;
        console.log(response.shipequipments);
        // console.log('Sample equipment:', this.allEquipmentDetails[0]);

        const commandCard = this.cards.find((card) => card.label === 'Command');
        if (commandCard) {
          commandCard.options = response.commands.map((item: any) => ({
            label: item.name,
            value: item.id,
          }));
          console.log(commandCard.options);
        }
      },
    });
  }

  applyFilter(card: any, value: any) {
    console.log(card, value);
    switch (card) {
      case 'Command':
        this.onCommandChange(value);
        break;
      case 'Ship':
        this.onShipChange(value);
        break;
      case 'Section':
        this.onSectionChange(value);
        break;
      case 'Group':
        this.onGroupChange(value);
        break;
      case 'Equipment':
        this.onEquipmentChange(value);
        break;
    }
  }
  resetFilters() {
    this.cards.forEach((card) => {
      card.selectedOption = null;
      if (card.label !== 'Command') {
        card.options = []; // Only clear options for non-root filters
      }
    });
    this.shipEquipments = [];
    this.selectedValue = false;
  }

  clearSelections() {
    this.cards.forEach((card) => (card.selectedOption = null));
    // this.updateChart();
  }
  onCommandChange(commandId: number) {
    console.log(commandId);
    this.apiService
      .get<any[]>(`master/ship/?command=${commandId}&dropdown=${true}`)
      .subscribe((headers) => {
        const shipcommandCard = this.cards.find(
          (card) => card.label === 'Ship'
        );
        if (shipcommandCard) {
          shipcommandCard.options = headers.map((header) => ({
            label: header.name,
            value: header.id,
          }));
          console.log(shipcommandCard.options);
        }
      });
  }
  onShipChange(shipId: number) {
    this.selecedShipId = shipId;
    this.apiService
      .get<any[]>(`master/section/?dropdown=${true}`)
      .subscribe((headers) => {
        const sectioncommandCard = this.cards.find(
          (card) => card.label === 'Section'
        );
        if (sectioncommandCard) {
          sectioncommandCard.options = headers.map((header: any) => ({
            label: header.name,
            value: header.id,
          }));
          console.log(sectioncommandCard.options);
        }
      });
  }
  onSectionChange(groupId: number) {
    this.apiService
      .get<any[]>(`master/group/?dropdown=${true}`)
      .subscribe((headers) => {
        console.log(headers);

        const groupcommandCard = this.cards.find(
          (card) => card.label === 'Group'
        );
        if (groupcommandCard) {
          groupcommandCard.options = headers.map((header) => ({
            label: header.name,
            value: header.id,
          }));
          console.log(groupcommandCard.options);
        }
      });
  }
  onGroupChange(equipmentId: number) {
    console.log(equipmentId);
    this.apiService
      .get<any[]>(`master/equipment/?dropdown=${true}`)
      .subscribe((headers) => {
        console.log(headers);

        const equipmentcommandCard = this.cards.find(
          (card) => card.label === 'Equipment'
        );
        if (equipmentcommandCard) {
          equipmentcommandCard.options = headers.map((header) => ({
            label: header.name,
            value: header.id,
          }));
        }
      });
  }
  onEquipmentChange(equipmentId: any) {
    this.apiService
      .get<any[]>(
        `sfd/equipment-ship-details/?equipment=${equipmentId}&ship=${this.selecedShipId}`
      )
      .subscribe((headers) => {
        console.log(headers);
        this.shipEquipments = headers;
      });
  }

  onRowSelected(row: any) {
    const equipmentId = row.equipment.id;
    this.selectedValue = true;
    this.apiService
      .get<any[]>(`sfd/hid-equipment-details/?equipment=${equipmentId}`)
      .subscribe({
        next: (data) => {
          console.log('HID Equipment Details:', data);
          this.hidEquipmentDetails = data;
        },
        error: (error) => {
          console.error('Error fetching HID equipment details:', error);
        },
      });
    if (this.hidEquipmentDetails && this.hidEquipmentDetails.length > 0) {
      const equipment = this.hidEquipmentDetails[0].equipment;

      console.log(equipment);

      this.hidSpecs = {
        Name: equipment.name,
        Model: equipment.model,
        Code: equipment.code,
        'Manufacture Name': equipment.manufacture_name,
        'Manufacture Address': equipment.manufacture_address,
        Country: equipment.country?.name,
        Type: equipment.type?.name,
        'Group Code': equipment.group?.code,
        Authority: equipment.authority,
        Obsolete: equipment.obsolete,
      };
    }
    this.apiService
      .get<any[]>(`sfd/equipment-specifications/?equipment=${equipmentId}`)
      .subscribe({
        next: (data) => {
          console.log('Equipment Specifications:', data);
          this.equipmentSpecifications = data;
        },
        error: (error) => {
          console.error('Error fetching equipment specifications:', error);
        },
      });

    if (
      this.equipmentSpecifications &&
      this.equipmentSpecifications.length > 0
    ) {
      const equipment = this.equipmentSpecifications[0].equipment;

      console.log(equipment);

      this.eqSpecs = {
        Name: this.equipmentSpecifications[0].specification_name,
        Unit: this.equipmentSpecifications[0].specification_unit,
        Value: this.equipmentSpecifications[0].specification_value,
        'Manufacture Name': equipment.manufacture_name,
        'Manufacture Address': equipment.manufacture_address,
        Country: equipment.country?.name,
        Type: equipment.type?.name,
        'Group Code': equipment.group?.code,
        Authority: equipment.authority,
        Obsolete: equipment.obsolete,
        'SFD Hierarchy': this.equipmentSpecifications[0].sfd_hierarchy.name,
        Hcode: this.equipmentSpecifications[0].sfd_hierarchy.h_code,
        'SFD Level': this.equipmentSpecifications[0].sfd_hierarchy.sfd_level,
        code: this.equipmentSpecifications[0].sfd_hierarchy.code,
        parent: this.equipmentSpecifications[0].sfd_hierarchy.parent,
      };
    }
  }
  exportOptions = [
    {
      label: 'Export as PDF',
      icon: 'pi pi-file-pdf',
      command: () => this.exportPDF(),
    },
    {
      label: 'Export as Excel',
      icon: 'pi pi-file-excel',
      command: () => this.exportExcel(),
    },
  ];

  exportExcel() {
    this.exportService.exportExcel(
      this.cols,
      this.shipEquipments,
      this.tableName
    );
  }
  exportPDF() {
    this.exportService.exportPDF(
      this.cols,
      this.shipEquipments,
      this.tableName
    );
  }

  setActiveTab(tabIndex: number): void {
    this.value = tabIndex;
  }
  stateOptions: any[] = [
    { label: 'Equipment Specification', value: 'equipment' },
    { label: 'HID Equipment', value: 'hid' },
    // { label: 'Generic Specification', value: 'generic' },
  ];
  tabvalue: string = 'equipment';
}
