import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ApiService } from '../../../services/api.service';

@Component({
  selector: 'app-sfd-change-request',
  standalone:false,
  templateUrl: './sfd-change-request.component.html',
  styleUrl: './sfd-change-request.component.css'
})
export class SfdChangeRequestComponent implements OnInit {
  isChecked: boolean = false;
  displayDialog: boolean = false;
  isMaximized: boolean = false;
  isEdit: boolean = false;
  sfdReferenceForm: FormGroup = new FormGroup({
    equipmentCodeName: new FormControl('', Validators.required),
    model: new FormControl('', Validators.required),
    nomenclature: new FormControl('', Validators.required),
    equipmentSerialNo: new FormControl('', Validators.required),
    oemPartNo: new FormControl(''),
    supplier: new FormControl(''),
    manufacturer: new FormControl(''),
    locationCode: new FormControl(''),
    locationOnBoard: new FormControl('', Validators.required),
    installationDate: new FormControl(''),
    removalDate: new FormControl(''),
    noOfFits: new FormControl(''),
    serviceLife: new FormControl(''),
    department: new FormControl('', Validators.required),
    parentEquipment: new FormControl(''),
    authorityForInstallation: new FormControl(''),
    installationRemarks: new FormControl(''),
    rhInInstallation: new FormControl(''),
    subDepartment: new FormControl(''),
    equipmentSpecifications: new FormControl('', Validators.required),
    insmaRemarks: new FormControl('', Validators.required),
  });
  shipOptions: any[] = [];
  equipmentOptions: any[] = [];
  locationOnBoardOptions: any[] = [];
  parentEquipmentOptions: any[] = [];
  subDepartmentOptions: any[] = [];
  manufacturerOptions: any[] = [];
  departmentOptions: any[] = [];

  // Table Columns Configuration
  tableColumns = [
    { field: 'ship', header: 'Ship Name', type: 'text', sortable: true, filterable: true },
    { field: 'equipment_name', header: 'Equipment Name', type: 'text', sortable: true, filterable: true },
    { field: 'location_code', header: 'Location Code', type: 'text', sortable: true, filterable: true },
    { field: 'location_on_board', header: 'Location On Board', type: 'text', sortable: true, filterable: true },
    { field: 'no_of_fits', header: 'No. Of Fits', type: 'number', sortable: true, filterable: true },
    { field: 'status', header: 'Active', type: 'text', sortable: true, filterable: true },
  ];
  

  // Dropdown Options
  unitTypeOptions= []
  groupOptions= []
  countryOptions= []
  supplierOptions= []
  modelOptions= []
  // Selected Values
  selectedUnitType: string = '';
  selectedGroup: string = '';
  selectedCountry: string = '';
  selectedSupplier: string = '';
  selectedModel: string = '';
  selectedEquipment: string = '';

  // Table Data
  tableData: any[]  =  [
    {
      "ship": "HDB MANAGEMENT",
      "equipment_name": "594071 WINDOW WIPER MOTOR",
      "location_code": "1",
      "location_on_board": "WHEELHOUSE",
      "no_of_fits": "2",
      "status": "Pending For Approval"
    },
    {
      "ship": "INS NIREEKSHAK",
      "equipment_name": "Auto Voltage Regulator (AVR) M/s Kaushik Electronics Model SES-12(S)(NS) (CC)",
      "location_code": "1",
      "location_on_board": "Shaft tunnel",
      "no_of_fits": "2",
      "status": "Pending For Approval"
    },
    {
      "ship": "INS TABAR",
      "equipment_name": "67300061 AUTO PLOTTER (NAKSH YOJANA)",
      "location_code": "2",
      "location_on_board": "Ops room",
      "no_of_fits": "1",
      "status": "Pending For Approval"
    },
    {
      "ship": "INS TABAR",
      "equipment_name": "64100021 PORTABLE DIVER DETECTION SONAR (PDDS) TATA POWER SED",
      "location_code": "2",
      "location_on_board": "FLYCO_AK630 DK(P)",
      "no_of_fits": "1",
      "status": "Pending For Approval"
    },
    {
      "ship": "INS TABAR",
      "equipment_name": "817001 I AUTOMATIC FIRE DETECTION SYS",
      "location_code": "3",
      "location_on_board": "DCHQ",
      "no_of_fits": "2",
      "status": "Pending For Approval"
    },
    {
      "ship": "INS CORA DIVH",
      "equipment_name": "582041 MOTOR A/C SEA WATER PUMP",
      "location_code": "1",
      "location_on_board": "FER",
      "no_of_fits": "2",
      "status": "Pending For Approval"
    },
    {
      "ship": "INS ARIGHAAT",
      "equipment_name": "M/s BAUER KOMPRESSOR",
      "location_code": "1",
      "location_on_board": "cic dk 2",
      "no_of_fits": "1",
      "status": "Pending For Approval"
    },
    {
        "ship": "INS KHAIJAR",
      "equipment_name": "NAVAL ADS-B",
      "location_code": "1",
      "location_on_board": "BRIDGE",
      "no_of_fits": "1",
      "status": "Pending For Approval"
    }
  ];
  constructor(private apiService: ApiService) {}
  ngOnInit(): void {
    this.apiCall();
    this.currentPageApi(0 ,0)
    console.log('SFD Component initialized with', this.tableData.length, 'records');
  }
  currentPageApi(page: number, pageSize: number){
    this.apiService.get(`sfd/sfd-change-requests/`).subscribe((res: any) => {
      // this.tableData = res;
    });
  }

  apiCall(){
    this.apiService.get('master/unit/').subscribe((res: any) => {
      this.unitTypeOptions = res;
    });
    
    this.apiService.get('master/ship/').subscribe((res: any) => {
      this.shipOptions = res;
    });
    
    this.apiService.get('master/group/').subscribe((res: any) => {
      this.groupOptions = res;
    });
    this.apiService.get('master/country/').subscribe((res: any) => {  
      this.countryOptions = res;
    });
    this.apiService.get('master/equipment/').subscribe((res: any) => {
      this.equipmentOptions = res;
    });
    this.apiService.get('master/supplier/').subscribe((res: any) => {
      this.supplierOptions = res;
    });
   
    this.apiService.get('master/parent-equipment/').subscribe((res: any) => {
      this.parentEquipmentOptions = res;
    });
    this.apiService.get('master/sub-department/').subscribe((res: any) => {
      this.subDepartmentOptions = res;
    });
    this.apiService.get('master/manufacturers/').subscribe((res: any) => {
      this.manufacturerOptions = res.data;
    });
    this.apiService.get('master/department/').subscribe((res: any) => {
      this.departmentOptions = res;
    });
  }

  openDialog(): void {
    this.isEdit = false;
    this.displayDialog = true;
  }

  closeDialog(): void {
    this.displayDialog = false;
  }

  saveReference(): void {
    console.log('Saving reference:', this.sfdReferenceForm.value);
    // Implement save logic
    this.closeDialog();
  }

  // Event Handlers
  onView(data: any): void {
    console.log('View SFD:', data);
    this.sfdReferenceForm.patchValue(data);
    this.openDialog();
    // Implement view logic
  }

  onEdit(data: any): void {
    console.log('Edit SFD:', data);
    this.sfdReferenceForm.patchValue(data);
    this.isEdit = true;
    this.openDialog();
    // Implement edit logic
  }

  onDelete(data: any): void {
    console.log('Delete SFD:', data);
    // Implement delete logic
  }

  onUnitTypeChange(): void {
    console.log('Unit Type changed to:', this.selectedUnitType);
    // Implement filtering logic
  }
  onShipChange(): void {
    console.log('Ship changed to:', this.selectedGroup);
    // Implement filtering logic
  }

  approveReference(): void {
    console.log('Approve Reference:', this.sfdReferenceForm.value);
    // Implement approve logic
  }

  rejectReference(): void {
    console.log('Reject Reference:', this.sfdReferenceForm.value);
    // Implement reject logic
  }

}
