import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../../../../services/api.service';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-document-details',
  standalone: false,
  templateUrl: './document-details.component.html',
})
export class DocumentDetailsComponent implements OnInit {
  showEditDialog = false;
  isEdit = false;
  documentForm=new FormGroup({
    document_type: new FormControl(''),
    reference_no: new FormControl(''),
    category: new FormControl(''),
    location: new FormControl(''),
    description: new FormControl(''),
  });
  documentTypeOptions: any[] = [];


  // Table Columns Configuration
  tableColumns = [
    { field: 'document_type', header: 'Document Type', type: 'text', sortable: true, filterable: true },
    { field: 'description', header: 'Description', type: 'text', sortable: true, filterable: true },
    { field: 'category', header: 'Category', type: 'number', sortable: true, filterable: true },
    { field: 'location', header: 'Location', type: 'text', sortable: true, filterable: true },
    { field: 'reference_no', header: 'Reference No', type: 'text', sortable: true, filterable: true },
    { field: 'status', header: 'Status', type: 'status', sortable: true, filterable: true },
  ];

  rowData: any;
  
  // Table Data
  tableData: any[]  = [
    {
      "document_type": "Technical",
      "description": "ANICAL & USER MANUAL FOR INTERATED EMCCA CONSOLE SIGNAL DESK& TECHANICALRUSER",
      "category": "CRNo.(4 1st Grp51SNo14",
      "location": "YY",
      "reference_no": 'ED555CYRDCG G',
      "status": 1
    },
    {
      "document_type": "Documentation",
      "description": "(COMPEX INTERFACE UNIT",
      "category": "MANUAL",
      "location": "UNE",
      "reference_no": 'ERTYUITT96',
      "status": 1
    }
  ];
  constructor(private apiService: ApiService, private route: ActivatedRoute, private router: Router) {}
  ngOnInit(): void {
    this.rowData = this.apiService.getData();
    this.currentPageApi(0 ,0)
    console.log('SFD Component initialized with', this.tableData.length, 'records');
  }
  currentPageApi(page: number, pageSize: number){
    this.apiService.get(`sfd/equipment-document-details/`).subscribe((res: any) => {
      // this.tableData = res;
    });
  }

  onView(data: any): void {
    this.documentForm.patchValue(data);
    this.showEditDialog = true;
    this.isEdit = false;
    this.documentForm.disable()
    console.log('View SFD:', data);
    this.rowData = data;
  }
  onEdit(data: any): void {
    this.documentForm.patchValue(data);
    console.log('Edit SFD:', data);
    this.rowData = data;
    this.showEditDialog = true;
    this.isEdit = true;
  }
  onAdd(data: any): void {
    this.showEditDialog = true;
    this.isEdit = false;
  }
  onDelete(data: any): void {
    console.log('Delete SFD:', data);
    
  }
  onSaveDocument(): void {
    console.log('Save Document:', this.documentForm.value);
  }
  onCancelEdit(): void {
    this.showEditDialog = false;
    this.documentForm.reset();
    this.documentForm.enable();
  }

  }