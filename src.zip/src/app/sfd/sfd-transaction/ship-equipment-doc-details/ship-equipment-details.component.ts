import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-ship-equipment-details',
  standalone:false,
  templateUrl: './ship-equipment-details.component.html',
  styleUrl: './ship-equipment-details.component.css'
})
export class ShipEquipmentDetailsComponent implements OnInit {
 

  // Table Columns Configuration
  tableColumns = [
    { field: 'equipment_code', header: 'Equipment Code', type: 'text', sortable: true, filterable: true },
    { field: 'equipment_name', header: 'Equipment Name', type: 'text', sortable: true, filterable: true },
    { field: 'equipment_model', header: 'Equipment Model', type: 'number', sortable: true, filterable: true },
  ];
  
  
  // Table Data
  tableData: any[]  = [{
    "equipment_code": "820465",
    "equipment_name": "SHIP INSTALLED CHEMICAL AGENT DETECTION SYS (E10278)",
    "equipment_model": "E10278"
  },
  {
    "equipment_code": "820465",
    "equipment_name": "SHIP INSTALLED CHEMICAL AGENT DETECTION SYS (E10278)",
    "equipment_model": "E10278"
  },
  {
    "equipment_code": "820112",
    "equipment_name": "SOQC VALVE (EPL2) KAMORTA CLASS",
    "equipment_model": "EPL2"
  },
  {
    "equipment_code": "820112",
    "equipment_name": "SOQC VALVE (EPL2) KAMORTA CLASS",
    "equipment_model": "EPL2"
  },
  {
    "equipment_code": "820112",
    "equipment_name": "SOQC VALVE (EPL2) KAMORTA CLASS",
    "equipment_model": "EPL2"
  },
  {
    "equipment_code": "820112",
    "equipment_name": "SOQC VALVE (EPL2) KAMORTA CLASS",
    "equipment_model": "EPL2"
  },
  {
    "equipment_code": "820111",
    "equipment_name": "SOQCV SYS (KEYSTONE) KAMORTA CLASS",
    "equipment_model": "KEYSTONE"
  },
  {
    "equipment_code": "820111",
    "equipment_name": "SOQCV SYS (KEYSTONE) KAMORTA CLASS",
    "equipment_model": "KEYSTONE"
  },
  {
    "equipment_code": "820111",
    "equipment_name": "SOQCV SYS (KEYSTONE) KAMORTA CLASS",
    "equipment_model": "KEYSTONE"
  },
  {
    "equipment_code": "820111",
    "equipment_name": "SOQCV SYS (KEYSTONE) KAMORTA CLASS",
    "equipment_model": "KEYSTONE"
  }]
  rowData: any[] = []
  constructor(private apiService: ApiService, private route: ActivatedRoute, private router: Router) {}
  ngOnInit(): void {
    this.currentPageApi(0 ,0)
    console.log('SFD Component initialized with', this.tableData.length, 'records');
  }
  currentPageApi(page: number, pageSize: number){
    this.apiService.get(`sfd/equipment-document-details/`).subscribe((res: any) => {
      // this.tableData = res;
    });
  }



  

  onView(data: any): void {
    console.log('View SFD:', data);
    this.rowData = data;
  }
  onEdit(data: any): void {
    console.log('Edit SFD:', data);
    this.rowData = data;
    this.apiService.setData(data);
    this.router.navigate(['/sfd/sfd-transactions/document-details']);
  }

  
}
