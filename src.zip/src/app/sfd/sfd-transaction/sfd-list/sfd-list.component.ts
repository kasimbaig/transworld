  import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ApiService } from '../../../services/api.service';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-sfd-list',
  standalone:false,
  templateUrl: './sfd-list.component.html',
  styleUrl: './sfd-list.component.css'
})
export class SfdListComponent implements OnInit {
  isChecked: boolean = false;
  displayDialog: boolean = false;
  isMaximized: boolean = false;
  sfdReferenceForm: FormGroup = new FormGroup({
    ship: new FormControl(''),
    equipment: new FormControl(''),
    model: new FormControl(''),
    nomenclature: new FormControl(''),
    oem_part_number: new FormControl(''),
    manufacturer: new FormControl(''),
    supplier: new FormControl(''),
    location_code: new FormControl(''),
    location_onboard: new FormControl(''),
    installation_date: new FormControl(''),
    removal_date: new FormControl(''),
    service_life: new FormControl(''),
    no_of_fits: new FormControl(''),
    department: new FormControl(''),
    parent_equipment: new FormControl(''),
    sub_department: new FormControl(''),
    installation_remarks: new FormControl(''),
    authority_for_installation: new FormControl(''),
    authority_for_removal: new FormControl(''),
    removal_remarks: new FormControl(''),
    included_in_dl: new FormControl(true)
  });
  equipmentOptions: any[] = [];
  supplierOptions: any[] = [];
  locationOnBoardOptions: any[] = [];
  
  subDepartmentOptions: any[] = [];
  manufacturerOptions: any[] = [];

  // Table Columns Configuration
  tableColumns = [
    { field: 'equipment_code', header: 'Equipment Code', type: 'number', sortable: true, filterable: true },
    { field: 'equipment_name', header: 'Equipment Name', type: 'text', sortable: true, filterable: true },
    { field: 'location_code', header: 'Location Code', type: 'number', sortable: true, filterable: true },
    { field: 'location_onboard', header: 'Location On Board', type: 'text', sortable: true, filterable: true },
    { field: 'nomenclature', header: 'Nomenclature', type: 'text', sortable: true, filterable: true },
    { field: 'no_of_fits', header: 'No. Of Fits', type: 'number', sortable: true, filterable: true },
    { field: 'maintop_number', header: 'Maintop Number', type: 'number', sortable: true, filterable: true },
    { field: 'status', header: 'Status', type: 'status', sortable: true, filterable: true },
  ];
  

  // Dropdown Options
  unitOptions= []

  shipOptions= []

  departmentOptions= []

  // Selected Values
  selectedUnit: string = '';
  selectedShip: string = '';
  selectedDepartment: string = '';

  // Table Data
  tableData: any[]  =  [
    {
      equipment_code: "10140",
      equipment_name: "DOCKING INSTRUCTIONS",
      location_code: "1",
      location_onboard: "VARIOUS LOCATIONS",
      nomenclature: "DOCKING INSTRUCTIONS",
      no_of_fits: "1",
      maintop_number: "10140",
      status: 1
    },
    {
      equipment_code: "10223",
      equipment_name: "HULL SURVEY",
      location_code: "1",
      location_onboard: "VARIOUS LOCATIONS",
      nomenclature: "SHIP’S HULL",
      no_of_fits: "1",
      maintop_number: "10223",
      status: 1 
    },
    {
      equipment_code: "10305",
      equipment_name: "APT CLUSTERS",
      location_code: "1",
      location_onboard: "VARIOUS LOCATIONS",
      nomenclature: "AIR PRESSURE TESTING AND CITADEL",
      no_of_fits: "28",
      maintop_number: "10305",
      status: 1
    },
    {
      equipment_code: "10335",
      equipment_name: "GAS CITADEL",
      location_code: "1",
      location_onboard: "CITADEL1TO7,BOTH GTR",
      nomenclature: "GAS CITADEL DELHI CLASS",
      no_of_fits: "5",
      maintop_number: "10323",
      status: 1
    },
    {
      equipment_code: "11023",
      equipment_name: "UNDER WATER PLATINGS",
      location_code: "1",
      location_onboard: "XXXX",
      nomenclature: "UNDER WATER PLATING",
      no_of_fits: "1",
      maintop_number: "11023",
      status: 1
    },
    {
      equipment_code: "11173",
      equipment_name: "RUDDER",
      location_code: "1",
      location_onboard: "PORT",
      nomenclature: "RUDDER PORT",
      no_of_fits: "1",
      maintop_number: "11173",
      status: 1
    },
    {
      equipment_code: "11173",
      equipment_name: "RUDDER",
      location_code: "2",
      location_onboard: "STBD",
      nomenclature: "RUDDER STBD",
      no_of_fits: "1",
      maintop_number: "11173",
      status: 1
    },
    {
      equipment_code: "11235",
      equipment_name: "SONAR DOME",
      location_code: "1",
      location_onboard: "U/W FR 23-28 CL",
      nomenclature: "SONAR DOME",
      no_of_fits: "1",
      maintop_number: "11273",
      status: 1
    }
  ];
  
  constructor(private apiService: ApiService, private toast: MessageService) {}
  ngOnInit(): void {
    this.apiCall();
    this.currentPageApi(0 ,0)
    console.log('SFD Component initialized with', this.tableData.length, 'records');
  }
  currentPageApi(page: number, pageSize: number){
    this.apiService.get(`sfd/sfd-details/`).subscribe((res: any) => {
      // this.tableData = res;
    });
  }

  apiCall(){
    this.apiService.get('master/unit/').subscribe((res: any) => {
      this.unitOptions = res;
    });
    this.apiService.get('master/ship/').subscribe((res: any) => {
      this.shipOptions = res;
    });
    this.apiService.get('master/department/').subscribe((res: any) => {
      this.departmentOptions = res;
    });
    this.apiService.get('master/supplier/').subscribe((res: any) => {
      this.supplierOptions = res;
    });
    this.apiService.get('master/location-on-board/').subscribe((res: any) => {
      this.locationOnBoardOptions = res;
    });
    this.apiService.get('master/equipment/').subscribe((res: any) => {
      this.equipmentOptions = res;
    });
    
    this.apiService.get('master/sub-department/').subscribe((res: any) => {
      this.subDepartmentOptions = res;
    });
    this.apiService.get('master/manufacturers/').subscribe((res: any) => {
      this.manufacturerOptions = res.data;
    });
  }

  openDialog(): void {
    this.displayDialog = true;
  }

  closeDialog(): void {
    this.displayDialog = false;
  }

  saveReference(): void {
    this.sfdReferenceForm.value.removal_date = this.apiService.formatDate(this.sfdReferenceForm.value.removal_date,'YYYY-MM-DD');
    this.sfdReferenceForm.value.installation_date = this.apiService.formatDate(this.sfdReferenceForm.value.installation_date,'YYYY-MM-DD');
    if(this.isEdit){
      this.apiService.put(`sfd/sfd-details/${this.sfdReferenceForm.value.id}`, this.sfdReferenceForm.value).subscribe((res: any) => {
        this.toast.add({severity:'success', summary: 'Success', detail: 'SFD Updated Successfully'});
        console.log(res);
        this.isEdit=false;
        this.currentPageApi(0 ,0)
      });
    }else{
      
      this.apiService.post('sfd/sfd-details/', this.sfdReferenceForm.value).subscribe((res: any) => {
        this.toast.add({severity:'success', summary: 'Success', detail: 'SFD Added Successfully'});
        console.log(res);
        this.currentPageApi(0 ,0)
      });
    }
   
    this.closeDialog();
  }

  // Event Handlers
  onView(data: any): void {
    console.log('View SFD:', data);
    this.sfdReferenceForm.patchValue(data);
    this.openDialog();
    // Implement view logic
  }
isEdit: boolean = false;
  onEdit(data: any): void {
    console.log('Edit SFD:', data);
this.isEdit = true;
    // Create a copy of data with properly formatted dates
    const formData = {
      ...data,
      removal_date: data.removal_date ? new Date(data.removal_date) : null,
      installation_date: data.installation_date ? new Date(data.installation_date) : null
    };

    this.sfdReferenceForm.patchValue(formData);
    this.openDialog();
    // Implement edit logic
  }

  onDelete(data: any): void {
    console.log('Delete SFD:', data);
    // Implement delete logic
  }

  // Filter Methods
  onUnitChange(): void {
    console.log('Unit changed to:', this.selectedUnit);
    // Implement filtering logic
  }

  onShipChange(): void {
    console.log('Ship changed to:', this.selectedShip);
    // Implement filtering logic
  }

  onDepartmentChange(): void {
    console.log('Department changed to:', this.selectedDepartment);
    // Implement filtering logic
  }
}
