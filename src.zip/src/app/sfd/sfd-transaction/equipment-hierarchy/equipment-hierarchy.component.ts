import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';

@Component({
  selector: 'app-equipment-hierarchy',
  standalone:false,
  templateUrl: './equipment-hierarchy.component.html',
  styleUrl: './equipment-hierarchy.component.css'
})
export class EquipmentHierarchyComponent implements OnInit {

  departmentOptions: any[] = [];
  shipOptions: any[] = [];
  unitTypeOptions= []
  
  searchValue: string = '';
  // Selected Values
  selectedUnitType: string = '';
  selectedShip: string = '';
  selectDepartment: string = '';

  // Table Data
  tableData: any[]  =  [
    {
     
      "nomenclature": "GT 3 LO PUMP",
      "equipment_code": "221121",
      "equipment_name": "MAIN ENGINE GAS TURBINE LUB OIL MD PUMP (K5807/8010) QVP SUDOEXPORT",
      "malntop_no": "31200",
      "location_onboard": "AFT GTR",
      "no_of_fits": "1",
      "parent_child": "---Please Select---",
      "parent_equipment": "MAIN ENGINE GAS TURBINE (DT-59) ZORYA",
      "parent_equipment_code": "31GT3",
      "parent_equipment_code_alt": "220001"
    },
    {

      "nomenclature": "GT 4 LO PUMP",
      "equipment_code": "221121",
      "equipment_name": "MAIN ENGINE GAS TURBINE LUB OIL MD PUMP (K5807/8010) QVP SUDOEXPORT",
      "malntop_no": "31200",
      "location_onboard": "AFT GTR",
      "no_of_fits": "1",
      "parent_child": "---Please Select---",
      "parent_equipment": "MAIN ENGINE GAS TURBINE (DT-59) ZORYA",
      "parent_equipment_code": "41GT4",
      "parent_equipment_code_alt": "220001"
    },
    {
   
      "nomenclature": "GT 1 LO COOLER",
      "equipment_code": "221131",
      "equipment_name": "MAIN ENGINE GAS TURBINE LUB OIL COOLER",
      "malntop_no": "22105",
      "location_onboard": "GT - 1 (PORT)",
      "no_of_fits": "1",
      "parent_child": "---Please Select---",
      "parent_equipment": "MAIN ENGINE GAS TURBINE (DT-59) ZORYA",
      "parent_equipment_code": "11GT1",
      "parent_equipment_code_alt": "220001"
    }
  ];
  constructor(private apiService: ApiService) {}
  ngOnInit(): void {
    this.apiCall();
    this.currentPageApi(0 ,0)
  }
  currentPageApi(page: number, pageSize: number){
    this.apiService.get(`sfd/equipment-hierarchy/`).subscribe((res: any) => {
      // this.tableData = res;
    });
  }

  apiCall(){
    this.apiService.get('master/unit/').subscribe((res: any) => {
      this.unitTypeOptions = res;
    });
    
    this.apiService.get('master/ship/').subscribe((res: any) => {
      this.shipOptions = res;
    });
    
   
    this.apiService.get('master/department/').subscribe((res: any) => {
      this.departmentOptions = res;
    });
  }

  // Event Handlers
  onView(data: any): void {
    console.log('View SFD:', data);
   
  }


  onUnitTypeChange(): void {
    console.log('Unit Type changed to:', this.selectedUnitType);
    // Implement filtering logic
  }
  onShipChange(): void {
    console.log('Ship changed to:', this.selectedShip);
    // Implement filtering logic
  }

  onDepartmentChange(): void {
    console.log('Department changed to:', this.selectDepartment);
    // Implement filtering logic
  }

  onSearchInput(value: string): string {
    const val=value.trim()
    return val || '';
  }

}
