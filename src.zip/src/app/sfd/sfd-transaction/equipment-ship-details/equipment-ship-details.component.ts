import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-equipment-ship-details',
  standalone:false,
  templateUrl: './equipment-ship-details.component.html',
  styleUrl: './equipment-ship-details.component.css'
})
export class EquipmentShipDetailsComponent implements OnInit {
  isChecked: boolean = false;
  displayDialog: boolean = false;
  isMaximized: boolean = false;
  sfdReferenceForm: FormGroup = new FormGroup({
    ship: new FormControl('',Validators.required),
    equipment_serial_number: new FormControl(''),
    supplier: new FormControl('',Validators.required),
    manufacturer: new FormControl('',Validators.required),
    location_code: new FormControl('',Validators.required),
    location_onboard: new FormControl('',Validators.required),
    installation_date: new FormControl(''),
    removal_date: new FormControl(''),
    oem_part_number: new FormControl(''),
    no_of_fits: new FormControl('',Validators.required),
    parent_equipment: new FormControl(''),
    sfd_group: new FormControl(''),
    department: new FormControl(''),
    remarks: new FormControl(''),
  });
  shipOptions: any[] = [];
  equipmentCodeNameOptions: any[] = [];
  locationOnBoardOptions: any[] = [];
  parentEquipmentOptions: any[] = [];
  subDepartmentOptions: any[] = [];
  manufacturerOptions: any[] = [];
  isEdit: boolean = false;
  // Table Columns Configuration
  tableColumns = [
    { field: 'ship', header: 'Ship Name', type: 'text', sortable: true, filterable: true },
    { field: 'location_code', header: 'Location Code', type: 'text', sortable: true, filterable: true },
    { field: 'location_onboard', header: 'Location On Board', type: 'text', sortable: true, filterable: true },
    { field: 'no_of_fits', header: 'No. Of Fits', type: 'number', sortable: true, filterable: true },
    { field: 'status', header: 'Status', type: 'status', sortable: true, filterable: true },
  ];
  

  // Dropdown Options
  sectionOptions= []
  groupOptions= []
  countryOptions= []
  supplierOptions= []
  modelOptions= []
  equipmentOptions= []
  // Selected Values
  selectedSection: string = '';
  selectedGroup: string = '';
  selectedCountry: string = '';
  selectedSupplier: string = '';
  selectedModel: string = '';
  selectedEquipment: string = '';

  // Table Data
  tableData: any[]  =[
    {
      "ship": "P31",
      "location_code": "INS KAVARATTI",
      "location_onboard": "1",
      "equipment_location": "MAIN MAST",
      "equipment_serial_number": "-",
      "no_of_fits": "1",
      "status": 1
    },
    {
      "ship": "P31",
      "location_code": "INS KAVARATTI",
      "location_onboard": "2",
      "equipment_location": "GAUTER DECK",
      "equipment_serial_number": "-",
      "no_of_fits": "1",
      "status": 1
    },
    {
      "ship": "P31",
      "location_code": "INS KAVARATTI",
      "location_onboard": "1",
      "equipment_location": "BRIDGE",
      "equipment_serial_number": "101",
      "no_of_fits": "6",
      "status": 1
    },
    {
      "ship": "A16",
      "location_code": "INS NISTAR",
      "location_onboard": "1",
      "equipment_location": "FER",
      "equipment_serial_number": "00-01/2526",
      "no_of_fits": "1",
      "status": 1
    },
    {
      "ship": "A16",
      "location_code": "INS NISTAR",
      "location_onboard": "4",
      "equipment_location": "AER",
      "equipment_serial_number": "00-0/2528",
      "no_of_fits": "8",
      "status": 1
    },
    {
      "ship": "A16",
      "location_code": "INS NISTAR",
      "location_onboard": "1",
      "equipment_location": "AER",
      "equipment_serial_number": "202122-1",
      "no_of_fits": "1",
      "status": 1
    },
    {
      "ship": "A16",
      "location_code": "INS NISTAR",
      "location_onboard": "2",
      "equipment_location": "AER",
      "equipment_serial_number": "202122-6",
      "no_of_fits": "80",
      "status": 1
    },
    {
      "ship": "A16",
      "location_code": "INS NISTAR",
      "location_onboard": "5",
      "equipment_location": "FER",
      "equipment_serial_number": "202122-2",
      "no_of_fits": "67",
      "status": 1
    }
  ];
  constructor(private apiService: ApiService, private toast: MessageService) {}
  ngOnInit(): void {
    this.apiCall();
    this.currentPageApi(0 ,0)
    console.log('SFD Component initialized with', this.tableData.length, 'records');
  }
  currentPageApi(page: number, pageSize: number){
    this.apiService.get(`sfd/equipment-ship-details/`).subscribe((res: any) => {
      // this.tableData = res;
    });
  }

  apiCall(){
    this.apiService.get('master/section/').subscribe((res: any) => {
      this.sectionOptions = res;
    });
    this.apiService.get('master/model/').subscribe((res: any) => {
      this.modelOptions = res;
    });
    this.apiService.get('master/ship/').subscribe((res: any) => {
      this.shipOptions = res;
    });
    
    this.apiService.get('master/group/').subscribe((res: any) => {
      this.groupOptions = res;
    });
    this.apiService.get('master/country/').subscribe((res: any) => {  
      this.countryOptions = res;
    });
    this.apiService.get('master/equipment/').subscribe((res: any) => {
      this.equipmentOptions = res;
    });
    this.apiService.get('master/supplier/').subscribe((res: any) => {
      this.supplierOptions = res;
    });
   
    this.apiService.get('master/parent-equipment/').subscribe((res: any) => {
      this.parentEquipmentOptions = res;
    });
    this.apiService.get('master/sub-department/').subscribe((res: any) => {
      this.subDepartmentOptions = res;
    });
    this.apiService.get('master/manufacturers/').subscribe((res: any) => {
      this.manufacturerOptions = res.data;
    });
  }

  openDialog(): void {
    this.displayDialog = true;
    this.sfdReferenceForm.reset();
   
  }

  closeDialog(): void {
    this.displayDialog = false;
    this.isEdit = false;
  }

  saveReference(): void {
    this.sfdReferenceForm.value.removal_date = this.apiService.formatDate(this.sfdReferenceForm.value.removal_date,'YYYY-MM-DD');
    this.sfdReferenceForm.value.installation_date = this.apiService.formatDate(this.sfdReferenceForm.value.installation_date,'YYYY-MM-DD');
    this.apiService.post('sfd/equipment-ship-details/', this.sfdReferenceForm.value).subscribe((res: any) => {
      this.toast.add({severity:'success', summary: 'Success', detail: 'Equipment Ship Details Added Successfully'});
      console.log(res);
      this.currentPageApi(0 ,0)
    });
    
    this.closeDialog();
  }

  // Event Handlers
  onView(data: any): void {
    const formData = {
      ...data,
      removal_date: data.removal_date ? new Date(data.removal_date) : null,
      installation_date: data.installation_date ? new Date(data.installation_date) : null
    };
    this.sfdReferenceForm.patchValue(formData);
    this.sfdReferenceForm.disable();
    this.openDialog();
    // Implement view logic
  }

  onEdit(data: any): void {
    this.isEdit = true;
    const formData = {
      ...data,
      removal_date: data.removal_date ? new Date(data.removal_date) : null,
      installation_date: data.installation_date ? new Date(data.installation_date) : null
    };
    this.sfdReferenceForm.patchValue(formData);
    this.sfdReferenceForm.enable();
    this.openDialog();
    // Implement edit logic
  }

  onDelete(data: any): void {
    console.log('Delete SFD:', data);
    // Implement delete logic
  }

  onSectionChange(): void {
    console.log('Section changed to:', this.selectedSection);
    // Implement filtering logic
  }

  onGroupChange(): void {
    console.log('Group changed to:', this.selectedGroup);
    // Implement filtering logic
  }   
  onCountryChange(): void {
    console.log('Country changed to:', this.selectedCountry);
    // Implement filtering logic
  }

  onSupplierChange(): void {
    console.log('Supplier changed to:', this.selectedSupplier);
    // Implement filtering logic
  } 
  onModelChange(): void {
    console.log('Model changed to:', this.selectedModel);
    // Implement filtering logic
  }
  onEquipmentChange(): void {
    console.log('Equipment changed to:', this.selectedEquipment);
    // Implement filtering logic
  }
}
