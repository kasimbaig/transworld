import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';

@Component({
  selector: 'app-sfd-approve-request',
  standalone:false,
  templateUrl: './sfd-approve-request.component.html',
  styleUrl: './sfd-approve-request.component.css'
})
export class SfdApproveRequestComponent implements OnInit {

  tableColumns = [
    { field: 'ship', header: 'Ship Name', type: 'text', sortable: true, filterable: true },
    { field: 'equipment_code_name', header: 'Equipment Code Name', type: 'text', sortable: true, filterable: true },
    { field: 'equipment_serial_number', header: 'Equipment Serial No.', type: 'text', sortable: true, filterable: true },
    { field: 'location_code', header: 'Location Code', type: 'text', sortable: true, filterable: true },
    { field: 'location_onboard', header: 'Location On Board', type: 'text', sortable: true, filterable: true },
    { field: 'auth_inst_date', header: 'Inst Date', type: 'date', sortable: true, filterable: true },
    { field: 'auth_removal', header: 'Auth Removal', type: 'date', sortable: true, filterable: true },
    { field: 'removal_date', header: 'Removal Date', type: 'date', sortable: true, filterable: true },
    { field: 'removal_remark', header: 'Removal Remark', type: 'date', sortable: true, filterable: true },
    { field: 'installation_rh', header: 'Installation RH', type: 'date', sortable: true, filterable: true },
    { field: 'no_of_fits', header: 'No. Of Fits', type: 'number', sortable: true, filterable: true },
    { field: 'request_type', header: 'Request Types', type: 'number', sortable: true, filterable: true },
  ];
  
  
  // Dropdown Options
  departmentOptions: any[] = [];
  shipOptions: any[] = [];
  unitTypeOptions= []
  
  // Selected Values
  selectedUnitType: string = '';
  selectedShip: string = '';
  selectDepartment: string = '';

  // Table Data
  tableData: any[]  = [
    {
      "ship": "INS RANVJAY",
      "equipment_code_name": "42511 I AUTOMATIC DISTILLING PLANT (I2-1/ TM) SNF",
      "equipment_serial_number": "2",
      "location_code": 2,
      "location_onboard":"BOILER ROOM (S)",
      "auth_inst_date": "HO ENC FAX NO. EG/3001/5/17 DATED 03 MAR 21",
      "auth_removal": "04-09-2024 00:00:00",
      "removal_date": "",
      "removal_remark": "obsolete",
      "installation_rh": "0",
      "no_of_fits": "1",
      "request_type": "Equipment Removal Request"
    },
    {
      "ship": "INS RANVJAY",
      "equipment_code_name": "42511 I AUTOMATIC DISTILLING PLANT (I2-1/ TM) SNF",
      "equipment_serial_number": "1",
      "location_code": 5,
      "location_onboard": "BOILER ROOM (P)",
      "auth_inst_date": "HO ENC FAX NO. EG/3001/5/17 DATED 03 MAR 21",
      "auth_removal": "02-09-2024 00:00:00",
      "removal_date": "",
      "removal_remark": "OBSOLETE",
      "installation_rh": "0",
      "no_of_fits": "1",
      "request_type": "Equipment Removal Request"
    },
    {
      "ship": "INS RANVJAY",
      "equipment_code_name": "42611 I DISTILLING PLANT SW PUMP (ECH-2571)",
      "equipment_serial_number": "2",
      "location_code": 5,
      "location_onboard": "BOILER ROOM (P)",
      "auth_inst_date": "HO ENC FAX NO. EG/3001/5/17 DATED 03 MAR 21",
      "auth_removal": "07-08-2024 00:00:00",
      "removal_date": "",
      "removal_remark": "OBSOLETE",
      "installation_rh": "0",
      "no_of_fits": "1",
      "request_type": "Equipment Removal Request"
    },
    {
      "ship": "INS RANVJAY",
      "equipment_code_name": "42611 I DISTILLING PLANT SW",
      "equipment_serial_number": "3",
        "location_code": 2,
      "location_onboard": "BOILER ROOM (S)",
      "auth_inst_date": "HO ENC FAX NO. EG/3001/5/17 DATED 03 MAR 21",
      "auth_removal": "17-09-2024 00:00:00",
      "removal_date": "",
      "removal_remark": "OBSOLETE",
      "installation_rh": "0",
      "no_of_fits": "1",
      "request_type": "Equipment Removal Request"
    }
  ];
  constructor(private apiService: ApiService) {}
  ngOnInit(): void {
    this.apiCall();
    this.currentPageApi(0 ,0)
    console.log('SFD Component initialized with', this.tableData.length, 'records');
  }
  currentPageApi(page: number, pageSize: number){
    this.apiService.get(`sfd/sfd-change-requests/`).subscribe((res: any) => {
      // this.tableData = res;
    });
  }

  apiCall(){
    this.apiService.get('master/unit/').subscribe((res: any) => {
      this.unitTypeOptions = res;
    });
    
    this.apiService.get('master/ship/').subscribe((res: any) => {
      this.shipOptions = res;
    });
    
   
    this.apiService.get('master/department/').subscribe((res: any) => {
      this.departmentOptions = res;
    });
  }

  // Event Handlers
  onView(data: any): void {
    console.log('View SFD:', data);
   
  }


  onUnitTypeChange(): void {
    console.log('Unit Type changed to:', this.selectedUnitType);
    // Implement filtering logic
  }
  onShipChange(): void {
    console.log('Ship changed to:', this.selectedShip);
    // Implement filtering logic
  }

  onDepartmentChange(): void {
    console.log('Department changed to:', this.selectDepartment);
    // Implement filtering logic
  }

  approveReference(): void {
    console.log('Approve Reference:', );
    // Implement approve logic
  }

  rejectReference(): void {
    console.log('Reject Reference:', );
    // Implement reject logic
  }

}
