import { Component, OnInit, HostListener } from '@angular/core'; // Import HostListener
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { CommonModule } from '@angular/common';
import { SfdMasterRoutingModule } from "../sfd-master/sfd-master-routing.module";

interface MasterMenuItem {
  label: string;
  icon: string;
  path: string;
}

@Component({
  selector: 'app-sfd-main-component',
  standalone: true,
  imports: [CommonModule, SfdMasterRoutingModule],
  templateUrl: './sfd-main-component.component.html',
  styleUrls: ['./sfd-main-component.component.css'],
})
export class SfdMainComponentComponent implements OnInit {
  activeSubPath: string = 'sfd-dashboard';
  showMasterDropdown: boolean = false;
  showTransactionsDropdown: boolean = false; // New property for Transactions dropdown

  masterMenuItems: MasterMenuItem[] = [
    {
      icon: 'fa-solid fa-chart-line',
      label: 'Generic Specification',
      path: 'sfd-masters/generic-specification',
    },
    {
      icon: 'fa-solid fa-sitemap',
      label: 'SFD Hierarchy',
      path: 'sfd-masters/sfd-hierarchy',
    },
    {
      icon: 'fa-solid fa-ship',
      label: 'Ship Details',
      path: 'sfd-masters/equipment-ship-details',
    },
    {
      icon: 'fa-solid fa-industry',
      label: 'Equipment Policies',
      path: 'sfd-masters/equipment-supplier',
    },
    {
      icon: 'fa-solid fa-toolbox',
      label: 'Equipment Details',
      path: 'sfd-masters/hide-equipment-details',
    },
    {
      icon: 'fa-solid fa-microchip',
      label: 'Equipment Specification',
      path: 'sfd-masters/equipment-specification',
    },
  ];

  transactionMenuItems: MasterMenuItem[] = [
    {
      icon: 'fa-solid fa-paperclip',
      label: 'Attach SFD By Reference',
      path: 'sfd-transactions/attach-sfd-by-reference',
    },
    {
      icon: 'fa-solid fa-list',
      label: 'SFD List',
      path: 'sfd-transactions/sfd-list',
    },
    {
      icon: 'fa-solid fa-ship',
      label: 'Equipment Ship Detail',
      path: 'sfd-transactions/equipment-ship-details',
    },
    {
      icon: 'fa-solid fa-file-alt',
      label: 'Ship Equipment Document Details',
      path: 'sfd-transactions/ship-equipment-doc-details',
    },
    
    {
      icon: 'fa-solid fa-plus-circle',
      label: 'SFD Change Request (Add)',
      path: 'sfd-transactions/sfd-change-request',
    },
    {
      icon: 'fa-solid fa-check',
      label: 'SFD Approve/Removal/Change Request',
      path: 'sfd-transactions/sfd-approve-removal-change-request',
    },
    {
      icon: 'fa-solid fa-sitemap',
      label: 'Equipment Hierarchy',
      path: 'sfd-transactions/equipment-hierarchy',
    },
    {
      icon: 'fa-solid fa-map-marker-alt',
      label: 'Eqpt Nomenclature, Location On Board',
      path: 'sfd-transactions/eqpt-nomenclature-location',
    },
  ];


  constructor(private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.updateActiveSubPath(this.router.url);

    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      this.updateActiveSubPath(event.urlAfterRedirects);
    });
  }

  private updateActiveSubPath(url: string): void {
    const urlSegments = url.split('/');
    const lastSegment = urlSegments.pop() || urlSegments.pop();

    if (!lastSegment) {
      this.activeSubPath = 'sfd-dashboard';
      return;
    }

    // Check if the current URL is for any of the Master sub-paths
    if (this.masterMenuItems.some(item => url.includes(item.path))) {
      this.activeSubPath = 'sfd-masters';
    }
    // Check if the current URL is for any of the Transactions sub-paths
    else if (this.transactionMenuItems.some(item => url.includes(item.path))) {
      this.activeSubPath = 'sfd-transactions'; // Set 'sfd-transactions' as active
    }
    // Check for other direct paths
    else if (['sfd-dashboard', 'sfd-reports'].includes(lastSegment)) {
      this.activeSubPath = lastSegment;
    }
    // Fallback to dashboard if URL doesn't match
    else {
      this.activeSubPath = 'sfd-dashboard';
    }
  }

  toggleMasterDropdown(): void {
    this.showMasterDropdown = !this.showMasterDropdown;
    this.showTransactionsDropdown = false; // Close other dropdown
  }

  toggleTransactionsDropdown(): void {
    this.showTransactionsDropdown = !this.showTransactionsDropdown;
    this.showMasterDropdown = false; // Close other dropdown
  }

  navigateToSFD(subPath: string): void {
    if (subPath === 'sfd-masters') {
      this.toggleMasterDropdown();
    } else if (subPath === 'sfd-transactions') {
      this.toggleTransactionsDropdown();
    }
    else {
      this.showMasterDropdown = false;
      this.showTransactionsDropdown = false;
      this.activeSubPath = subPath;
      this.router.navigate([subPath], { relativeTo: this.activatedRoute });
    }
  }

  navigateToMasterSubItem(masterPath: string): void {
    this.showMasterDropdown = false;
    this.activeSubPath = 'sfd-masters';
    this.router.navigate([masterPath], { relativeTo: this.activatedRoute });
  }

  navigateToTransactionSubItem(transactionPath: string): void {
    this.showTransactionsDropdown = false; // Close dropdown after selection
    this.activeSubPath = 'sfd-transactions'; // Keep 'Transactions' active
    this.router.navigate([transactionPath], { relativeTo: this.activatedRoute });
  }

  @HostListener('document:click', ['$event'])
  onClickOutside(event: Event) {
    const target = event.target as HTMLElement;
    if (!target.closest('.masters-dropdown-container') && !target.closest('.transactions-dropdown-container')) {
      this.showMasterDropdown = false;
      this.showTransactionsDropdown = false;
    }
  }
}